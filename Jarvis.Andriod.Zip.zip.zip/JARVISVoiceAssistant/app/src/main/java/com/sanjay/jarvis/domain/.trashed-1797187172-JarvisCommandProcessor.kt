package com.sanjay.jarvis.domain

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.location.Location
import android.location.LocationManager
import android.os.BatteryManager
import com.sanjay.jarvis.model.AiBrainPrefs
import com.sanjay.jarvis.model.ConversationTopic
import com.sanjay.jarvis.model.JarvisMessage
import com.sanjay.jarvis.model.JarvisTask
import com.sanjay.jarvis.model.LanguageMode
import com.sanjay.jarvis.model.PendingTaskDraft
import com.sanjay.jarvis.model.SmartMemoryItem
import com.sanjay.jarvis.model.TaskPriority
import com.sanjay.jarvis.model.TaskStatus
import com.sanjay.jarvis.model.WeatherData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Date
import java.util.Locale
import java.util.UUID

data class JarvisCommandOutput(
    val englishText: String,
    val tamilText: String,
    val weather: WeatherData? = null,
    val taskHighlights: List<JarvisTask> = emptyList(),
    val addedTask: JarvisTask? = null,
    val completedTaskId: String? = null,
    val deletedTaskId: String? = null,
    val updatedDraft: PendingTaskDraft? = null,
    val clearDraft: Boolean = false,
    val openTasksTab: Boolean = false,
    val openSettingsSheet: Boolean = false,
    val launchPackageOrUrl: String? = null,
    val launchLabel: String? = null,
    val usedExternalAi: Boolean = false,
    val contextTopic: ConversationTopic = ConversationTopic.GENERAL,
    val contextEntityCity: String? = null,
    val contextLanguage: String = "english"
)

class JarvisCommandProcessor(private val context: Context) {

    private val aiBrainService = JarvisAiBrainService()

    fun getBatteryPercent(): Int {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        val pct = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: 96
        return if (pct in 1..100) pct else 96
    }

    suspend fun process(
        rawCommand: String,
        userName: String,
        tasks: List<JarvisTask>,
        pendingDraft: PendingTaskDraft?,
        hasLocationPermission: Boolean,
        languageMode: LanguageMode = LanguageMode.BILINGUAL,
        aiPrefs: AiBrainPrefs = AiBrainPrefs(),
        sessionContext: List<JarvisMessage> = emptyList(),
        savedMemories: List<SmartMemoryItem> = emptyList()
    ): JarvisCommandOutput {
        val query = rawCommand.trim()
        val lower = query.lowercase(Locale.ROOT)
        val nowMs = System.currentTimeMillis()
        val freshWindow = sessionContext
            .filter { it.id != "init" && !it.id.startsWith("init-") && (nowMs - it.createdAtMillis) <= 30 * 60 * 1000L }
            .takeLast(8)
        val activeTopic = freshWindow.lastOrNull { it.contextTopic != null && (nowMs - it.createdAtMillis) <= 15 * 60 * 1000L }?.contextTopic
        val activeCity = freshWindow.lastOrNull { !it.contextEntityCity.isNullOrBlank() && (nowMs - it.createdAtMillis) <= 15 * 60 * 1000L }?.contextEntityCity
        val priorLang = freshWindow.lastOrNull { !it.contextLanguage.isNullOrBlank() }?.contextLanguage ?: "english"
        val detectedLang = detectPreferredLanguage(query, priorLang)

        // 1. Handle ongoing task clarification reply
        if (pendingDraft != null && !isExplicitOtherCommand(lower)) {
            if (Regex("\\b(cancel|stop|nevermind|vendaam|vendam)\\b|வேண்டாம்").containsMatchIn(lower)) {
                return JarvisCommandOutput(
                    englishText = "No problem, $userName. Cancelled that pending task.",
                    tamilText = "சரி $userName, அந்த டாஸ்க் ரத்து செய்யப்பட்டது buddy.",
                    clearDraft = true,
                    contextTopic = ConversationTopic.TASK,
                    contextLanguage = detectedLang
                )
            }
            val parsedDt = extractDateAndTime(query)
            if (parsedDt.ambiguousDate || parsedDt.ambiguousTime || (parsedDt.dueDate == null && parsedDt.dueTime == null)) {
                return JarvisCommandOutput(
                    englishText = "Could you clarify the clear date and AM/PM time for \"${pendingDraft.title}\", buddy?",
                    tamilText = "\"${pendingDraft.title}\" டாஸ்க்கிற்கு சரியான தேதி மற்றும் AM/PM நேரத்தைச் சொல்லுங்கள் buddy.",
                    updatedDraft = pendingDraft,
                    contextTopic = ConversationTopic.TASK,
                    contextLanguage = detectedLang
                )
            }
            val created = JarvisTask(
                id = "task-${UUID.randomUUID()}",
                title = pendingDraft.title,
                dueDate = parsedDt.dueDate ?: pendingDraft.dueDate ?: LocalDate.now().toString(),
                dueTime = parsedDt.dueTime ?: pendingDraft.dueTime,
                priority = pendingDraft.priority,
                reminderEnabled = pendingDraft.reminderEnabled,
                status = TaskStatus.PENDING
            )
            return JarvisCommandOutput(
                englishText = "Task added, $userName: \"${created.title}\".",
                tamilText = "டாஸ்க் சேர்க்கப்பட்டது buddy: \"${created.title}\".",
                addedTask = created,
                taskHighlights = listOf(created),
                clearDraft = true,
                contextTopic = ConversationTopic.TASK,
                contextLanguage = detectedLang
            )
        }

        // 2. App Launch Commands
        if (lower.contains("youtube") || lower.contains("யூடியூப்")) {
            return JarvisCommandOutput(
                englishText = "Sure buddy, opening YouTube.",
                tamilText = "நிச்சயமாக buddy, யூடியூப் திறக்கப்படுகிறது.",
                launchPackageOrUrl = "https://www.youtube.com",
                launchLabel = "YouTube",
                contextTopic = ConversationTopic.APP,
                contextLanguage = detectedLang
            )
        }
        if (lower.contains("whatsapp") || lower.contains("வாட்ஸ்அப்")) {
            return JarvisCommandOutput(
                englishText = "Sure buddy, opening WhatsApp.",
                tamilText = "நிச்சயமாக buddy, வாட்ஸ்அப் திறக்கப்படுகிறது.",
                launchPackageOrUrl = "com.whatsapp",
                launchLabel = "WhatsApp",
                contextTopic = ConversationTopic.APP,
                contextLanguage = detectedLang
            )
        }
        if (lower.contains("map") || lower.contains("maps") || lower.contains("மேப்ஸ்")) {
            return JarvisCommandOutput(
                englishText = "Sure buddy, opening Google Maps.",
                tamilText = "நிச்சயமாக buddy, கூகிள் மேப்ஸ் திறக்கப்படுகிறது.",
                launchPackageOrUrl = "https://www.google.com/maps",
                launchLabel = "Google Maps",
                contextTopic = ConversationTopic.APP,
                contextLanguage = detectedLang
            )
        }
        if (lower.contains("setting") || lower.contains("அமைப்புகள்")) {
            return JarvisCommandOutput(
                englishText = "Sure buddy, opening Settings.",
                tamilText = "நிச்சயமாக buddy, அமைப்புகள் திறக்கப்படுகிறது.",
                openSettingsSheet = true,
                contextTopic = ConversationTopic.APP,
                contextLanguage = detectedLang
            )
        }

        // 3. Weather Command (supports Today/Tomorrow/Day After + Context Follow-up)
        if (isWeatherQuery(lower)) {
            val dayOffset = detectFollowUpDayOffset(lower) ?: 0
            return handleWeather(
                extractCityFromWeatherQuery(query) ?: activeCity,
                lower,
                userName,
                hasLocationPermission,
                dayOffset,
                detectedLang
            )
        }

        val followUpDay = detectFollowUpDayOffset(lower)
        if (activeTopic == ConversationTopic.WEATHER && !activeCity.isNullOrBlank()) {
            val isFollowUp = followUpDay != null ||
                Regex("\\b(rain|mazhai|humidity|wind|epdi|eppadi|what about|how about)\\b").containsMatchIn(lower)
            if (isFollowUp && !lower.contains("task") && !lower.contains("battery")) {
                return handleWeather(
                    activeCity,
                    lower,
                    userName,
                    hasLocationPermission,
                    followUpDay ?: 0,
                    detectedLang
                )
            }
        }

        if (activeTopic == ConversationTopic.TASK && followUpDay == 1 && lower.split(Regex("\\s+")).size <= 4) {
            return handleTaskCommand("show tomorrow tasks", "show tomorrow tasks", userName, tasks)
                .copy(contextLanguage = detectedLang)
        }

        // 4. Task Manager Commands
        if (isTaskQuery(lower)) {
            return handleTaskCommand(query, lower, userName, tasks).copy(contextLanguage = detectedLang)
        }

        // 5. Battery, Time, Date, Good Morning, Daily Briefing, System Status
        if (lower.contains("battery") || lower.contains("பேட்டரி")) {
            val pct = getBatteryPercent()
            return JarvisCommandOutput(
                englishText = "Battery is at $pct%. All systems nominal, $userName.",
                tamilText = "Battery level ippo $pct% irukku buddy. All power systems stable, $userName!",
                contextTopic = ConversationTopic.BATTERY,
                contextLanguage = detectedLang
            )
        }
        if (lower.contains("time") || lower.contains("நேரம்") || lower.contains("மணி")) {
            val nowTime = LocalTime.now().format(DateTimeFormatter.ofPattern("h:mm a", Locale.US))
            return JarvisCommandOutput(
                englishText = "The current time is $nowTime, $userName.",
                tamilText = "Ippo time $nowTime, buddy.",
                contextLanguage = detectedLang
            )
        }
        if (lower.contains("date") || lower.contains("today") || lower.contains("தேதி") || lower.contains("இன்று")) {
            val todayFormatted = SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.US).format(Date())
            return JarvisCommandOutput(
                englishText = "Today is $todayFormatted, buddy.",
                tamilText = "Innaiku date $todayFormatted, $userName!",
                contextLanguage = detectedLang
            )
        }
        if (lower.contains("good morning") || lower.contains("காலை வணக்கம்")) {
            val pct = getBatteryPercent()
            val nowTime = LocalTime.now().format(DateTimeFormatter.ofPattern("h:mm a", Locale.US))
            return JarvisCommandOutput(
                englishText = "Good morning, $userName. JARVIS is online and ready. The current time is $nowTime with battery at $pct%. Have a great day, buddy.",
                tamilText = "காலை வணக்கம் $userName! இப்போது நேரம் $nowTime, battery $pct% உள்ளது. Have a great day, buddy!",
                contextTopic = ConversationTopic.BRIEFING,
                contextLanguage = detectedLang
            )
        }
        if (lower.contains("daily briefing") || lower.contains("briefing")) {
            val pct = getBatteryPercent()
            val pendingCount = tasks.count { it.status == TaskStatus.PENDING }
            return JarvisCommandOutput(
                englishText = "Good day $userName, here is your daily briefing: Battery is at $pct% and you have $pendingCount pending tasks. Keep pushing forward, buddy!",
                tamilText = "$userName, இதோ உங்கள் daily briefing: Battery $pct%, நிலுவையில் $pendingCount டாஸ்க்குகள் உள்ளன buddy!",
                contextTopic = ConversationTopic.BRIEFING,
                contextEntityCity = activeCity,
                contextLanguage = detectedLang
            )
        }
        if (lower.contains("system status")) {
            return JarvisCommandOutput(
                englishText = "All systems are fully operational, $userName. JARVIS is online and ready.",
                tamilText = "அனைத்து அமைப்புகளும் முழுமையாக செயல்படுகின்றன, $userName.",
                contextLanguage = detectedLang
            )
        }
        if (lower == "hey jarvis" || lower == "jarvis" || lower.startsWith("hey jarvis")) {
            return JarvisCommandOutput(
                englishText = "Yes buddy, I'm listening.",
                tamilText = "சொல்லுங்க buddy, கேட்கிறேன்.",
                contextLanguage = detectedLang
            )
        }

        // 6. Modular Advanced AI Brain (Smart Context Window, Smart Intent Detection & Natural Conversation)
        val brain = aiBrainService.think(
            prompt = query,
            userName = userName,
            languageMode = languageMode,
            aiPrefs = aiPrefs,
            sessionContext = freshWindow,
            savedMemories = savedMemories
        )

        if (brain.usedExternalAi) {
            when (brain.intent) {
                "weather" -> {
                    val dayOff = when (brain.forecastDay) {
                        "day_after" -> 2
                        "tomorrow" -> 1
                        else -> followUpDay ?: 0
                    }
                    return handleWeather(
                        brain.extractedCity ?: activeCity,
                        lower,
                        userName,
                        hasLocationPermission,
                        dayOff,
                        brain.detectedLanguage
                    ).copy(usedExternalAi = true)
                }
                "task" -> return handleTaskCommand(query, lower, userName, tasks)
                    .copy(usedExternalAi = true, contextLanguage = brain.detectedLanguage)
            }
        }

        return JarvisCommandOutput(
            englishText = brain.replyEn,
            tamilText = brain.replyTa,
            usedExternalAi = brain.usedExternalAi,
            contextTopic = activeTopic ?: ConversationTopic.GENERAL,
            contextEntityCity = activeCity,
            contextLanguage = brain.detectedLanguage
        )
    }

    private fun detectPreferredLanguage(input: String, fallback: String): String {
        if (input.any { it in '\u0B80'..'\u0BFF' }) return "tamil"
        val tanglish = Regex("\\b(epdi|eppadi|iruku|irukku|enna|sollu|pannu|venum|naalaiku|innaiku|nandri|mazhai)\\b", RegexOption.IGNORE_CASE)
        if (tanglish.containsMatchIn(input)) return "tanglish"
        val lower = input.trim().lowercase(Locale.ROOT)
        if (Regex("^(and|what about|tomorrow|today|rain)\\??$").matches(lower)) return fallback
        return "english"
    }

    private fun detectFollowUpDayOffset(lower: String): Int? = when {
        Regex("\\b(day after tomorrow|naalai marunaal)\\b|நாளை மறுநாள்").containsMatchIn(lower) -> 2
        Regex("\\b(tomorrow|tmrw|naalaiku|nalaiku)\\b|நாளை").containsMatchIn(lower) -> 1
        Regex("\\b(today|innaiku|inniku)\\b|இன்னைக்கு").containsMatchIn(lower) -> 0
        else -> null
    }

    private fun isExplicitOtherCommand(lower: String): Boolean =
        lower.contains("weather") || lower.contains("battery") || lower.contains("youtube") || lower.contains("good morning")

    private fun isWeatherQuery(lower: String): Boolean =
        Regex("\\b(weather|forecast|temperature|rain|mazhai|vaanilai|vanilai)\\b").containsMatchIn(lower) ||
            lower.contains("வானிலை") || lower.contains("மழை")

    private fun isTaskQuery(lower: String): Boolean =
        Regex("\\b(task|tasks|todo|reminder|remind me|add pannu|mudinjiduchu)\\b").containsMatchIn(lower) ||
            lower.contains("டாஸ்க்") ||
            (Regex("\\b(naalaiku|innaiku|naalai marunaal)\\b").containsMatchIn(lower) &&
                Regex("\\b(pannanum|seiyanum|vaikanum)\\b").containsMatchIn(lower))

    private fun handleTaskCommand(
        query: String,
        lower: String,
        userName: String,
        tasks: List<JarvisTask>
    ): JarvisCommandOutput {
        if (Regex("\\b(open|launch)\\s+(?:the\\s+)?task\\s*(?:manager|screen|list)\\b").containsMatchIn(lower)) {
            return JarvisCommandOutput(
                englishText = "Opening your Task Manager, $userName.",
                tamilText = "உங்கள் டாஸ்க் மேனேஜரை திறக்கிறேன் buddy.",
                openTasksTab = true
            )
        }

        // Complete task
        if (Regex("\\b(mark|complete|finish|done|mudinjiduchu)\\b").containsMatchIn(lower)) {
            val pending = tasks.filter { it.status == TaskStatus.PENDING }
            val target = if (lower.contains("first") || lower.contains("முதல்")) {
                pending.firstOrNull()
            } else {
                pending.firstOrNull { lower.contains(it.title.lowercase(Locale.ROOT)) } ?: pending.firstOrNull()
            }
            return if (target != null) {
                JarvisCommandOutput(
                    englishText = "Done, $userName! Marked \"${target.title}\" as completed.",
                    tamilText = "சூப்பர் buddy! \"${target.title}\" டாஸ்க் முடிந்ததாக குறிக்கப்பட்டது.",
                    completedTaskId = target.id,
                    taskHighlights = listOf(target.copy(status = TaskStatus.COMPLETED))
                )
            } else {
                JarvisCommandOutput(
                    englishText = "I couldn't find a matching pending task to complete, $userName.",
                    tamilText = "பொருந்தும் டாஸ்க் எதுவும் கிடைக்கவில்லை buddy."
                )
            }
        }

        // Delete task
        if (Regex("\\b(delete|remove)\\b|நீக்கு").containsMatchIn(lower)) {
            val needle = query
                .replace(Regex("^(hey|hi|hello|ok)?\\s*jarvis[,.:\\s]*", RegexOption.IGNORE_CASE), "")
                .replace(Regex("\\b(delete|remove|the|my|task|to|called|please)\\b", RegexOption.IGNORE_CASE), " ")
                .replace(Regex("\\s+"), " ")
                .trim()
                .lowercase(Locale.ROOT)
            val target = tasks.firstOrNull {
                needle.isNotEmpty() && it.title.lowercase(Locale.ROOT).contains(needle)
            } ?: if (lower.contains("first")) tasks.firstOrNull() else null

            return if (target != null) {
                JarvisCommandOutput(
                    englishText = "Removed \"${target.title}\" from your task list, $userName.",
                    tamilText = "\"${target.title}\" டாஸ்க் நீக்கப்பட்டது buddy.",
                    deletedTaskId = target.id,
                    taskHighlights = listOf(target)
                )
            } else {
                JarvisCommandOutput(
                    englishText = "I couldn't find that task to delete, $userName.",
                    tamilText = "நீக்க வேண்டிய டாஸ்க் கிடைக்கவில்லை buddy."
                )
            }
        }

        // List tasks
        if (Regex("\\b(show|list|what are|enna|iruku|irukku)\\b|காட்டு|இருக்கு").containsMatchIn(lower) &&
            !Regex("\\b(add|create|remind|pannanum)\\b").containsMatchIn(lower)
        ) {
            val today = LocalDate.now().toString()
            val filterToday = lower.contains("today") || lower.contains("innaiku") || lower.contains("இன்னைக்கு")
            val pending = tasks.filter {
                it.status == TaskStatus.PENDING && (!filterToday || it.dueDate == today)
            }
            return if (pending.isEmpty()) {
                JarvisCommandOutput(
                    englishText = "You have no pending tasks${if (filterToday) " for today" else ""}, $userName. All clear!",
                    tamilText = "நிலுவையில் எந்த டாஸ்க்கும் இல்லை buddy!"
                )
            } else {
                val summary = pending.take(3).mapIndexed { i, t -> "${i + 1}. ${t.title}" }.joinToString(". ")
                JarvisCommandOutput(
                    englishText = "You have ${pending.size} task(s), $userName: $summary.",
                    tamilText = "மொத்தம் ${pending.size} டாஸ்க் இருக்கு buddy: $summary.",
                    taskHighlights = pending.take(5)
                )
            }
        }

        // Add task with Tamil/Tanglish dates + ambiguity clarification
        val dt = extractDateAndTime(query)
        val cleanTitle = cleanTaskTitle(query, dt.matchedPhrases)
        val priority = when {
            Regex("\\b(high priority|urgent|important|mukkiyam)\\b").containsMatchIn(lower) -> TaskPriority.HIGH
            Regex("\\b(low priority|no rush)\\b").containsMatchIn(lower) -> TaskPriority.LOW
            else -> TaskPriority.MEDIUM
        }

        if (dt.ambiguousDate || dt.ambiguousTime) {
            val draft = PendingTaskDraft(
                title = cleanTitle,
                dueDate = dt.dueDate,
                dueTime = dt.dueTime,
                priority = priority,
                reminderEnabled = true,
                clarificationReason = if (dt.ambiguousTime) "time" else "date"
            )
            return JarvisCommandOutput(
                englishText = "I got \"$cleanTitle\", buddy — did you mean morning (AM) or evening (PM), and which day?",
                tamilText = "\"$cleanTitle\" டாஸ்க்கிற்கு சரியான தேதி மற்றும் AM/PM நேரத்தைச் சொல்லுங்கள் buddy.",
                updatedDraft = draft
            )
        }

        val task = JarvisTask(
            id = "task-${UUID.randomUUID()}",
            title = cleanTitle,
            dueDate = dt.dueDate,
            dueTime = dt.dueTime,
            priority = priority,
            reminderEnabled = true,
            status = TaskStatus.PENDING
        )
        return JarvisCommandOutput(
            englishText = "Task added, $userName: \"${task.title}\".",
            tamilText = "டாஸ்க் சேர்க்கப்பட்டது buddy: \"${task.title}\".",
            addedTask = task,
            taskHighlights = listOf(task)
        )
    }

    private data class DateTimeParseResult(
        val dueDate: String? = null,
        val dueTime: String? = null,
        val ambiguousDate: Boolean = false,
        val ambiguousTime: Boolean = false,
        val matchedPhrases: List<String> = emptyList()
    )

    private fun extractDateAndTime(raw: String): DateTimeParseResult {
        val lower = raw.lowercase(Locale.ROOT)
        val matched = mutableListOf<String>()
        var dueDate: String? = null
        var dueTime: String? = null
        var ambiguousDate = false
        var ambiguousTime = false

        val today = LocalDate.now()
        val dayAfterRegex = Regex("\\b(day after tomorrow|naalai marunaal|nalai marunal)\\b|நாளை மறுநாள்", RegexOption.IGNORE_CASE)
        val tomorrowRegex = Regex("\\b(tomorrow|naalaiku|nalaiku)\\b|நாளைக்கு|நாளை", RegexOption.IGNORE_CASE)
        val todayRegex = Regex("\\b(today|innaiku|inniku)\\b|இன்னைக்கு|இன்று", RegexOption.IGNORE_CASE)

        when {
            Regex("\\b(today or tomorrow|next week|sometime|one day)\\b").containsMatchIn(lower) -> ambiguousDate = true
            dayAfterRegex.containsMatchIn(raw) -> {
                dueDate = today.plusDays(2).toString()
                matched += dayAfterRegex.find(raw)?.value.orEmpty()
            }
            tomorrowRegex.containsMatchIn(raw) -> {
                dueDate = today.plusDays(1).toString()
                matched += tomorrowRegex.find(raw)?.value.orEmpty()
            }
            todayRegex.containsMatchIn(raw) -> {
                dueDate = today.toString()
                matched += todayRegex.find(raw)?.value.orEmpty()
            }
        }

        val amPmRegex = Regex("\\b(?:at\\s+)?(\\d{1,2})(?::([0-5]\\d))?\\s*(am|pm|a\\.m\\.|p\\.m\\.)\\b", RegexOption.IGNORE_CASE)
        val bareHourRegex = Regex("(?:\\bat\\s+(\\d{1,2})(?::([0-5]\\d))?\\b|\\b(\\d{1,2})\\s*(?:mani|o'clock)\\b)", RegexOption.IGNORE_CASE)

        val amPmMatch = amPmRegex.find(raw)
        if (Regex("\\b(later|aprom|sometime|morning or evening)\\b").containsMatchIn(lower)) {
            ambiguousTime = true
        } else if (amPmMatch != null) {
            var hour = amPmMatch.groupValues[1].toIntOrNull() ?: 9
            val min = amPmMatch.groupValues[2].toIntOrNull() ?: 0
            val isPm = amPmMatch.groupValues[3].lowercase(Locale.ROOT).startsWith("p")
            if (isPm && hour != 12) hour += 12
            if (!isPm && hour == 12) hour = 0
            dueTime = String.format(Locale.US, "%02d:%02d", hour.coerceIn(0, 23), min.coerceIn(0, 59))
            matched += amPmMatch.value
        } else {
            val bare = bareHourRegex.find(raw)
            if (bare != null) {
                ambiguousTime = true
                matched += bare.value
            }
        }

        return DateTimeParseResult(dueDate, dueTime, ambiguousDate, ambiguousTime, matched)
    }

    private fun cleanTaskTitle(raw: String, matchedPhrases: List<String>): String {
        var text = raw
        matchedPhrases.filter { it.isNotBlank() }.forEach { phrase ->
            text = text.replace(Regex(Regex.escape(phrase), RegexOption.IGNORE_CASE), " ")
        }
        text = text
            .replace(Regex("^(?:hey|hi|hello|ok)?\\s*jarvis[,.:\\s]*", RegexOption.IGNORE_CASE), "")
            .replace(Regex("\\b(add a task(?: to)?|add task(?: to)?|remind me(?: to)?|nu task add pannu|task add pannu|pannanum)\\b", RegexOption.IGNORE_CASE), " ")
            .replace(Regex("\\s+"), " ")
            .trim(' ', '.', ',', ':', '!')
        return if (text.isBlank()) "Untitled Task" else text.replaceFirstChar { it.uppercaseChar() }
    }

    private suspend fun handleWeather(
        explicitCity: String?,
        lower: String,
        userName: String,
        hasLocationPermission: Boolean,
        dayOffset: Int = 0,
        preferredLang: String = "english"
    ): JarvisCommandOutput = withContext(Dispatchers.IO) {
        val city = explicitCity?.trim()?.ifBlank { null }
        try {
            val coords: Pair<Double, Double>?
            var cityLabel: String
            var region: String? = null
            var country: String? = null

            if (city != null) {
                val geoUrl = "https://geocoding-api.open-meteo.com/v1/search?name=${URLEncoder.encode(city, "UTF-8")}&count=1&language=en&format=json"
                val geoJson = JSONObject(httpGet(geoUrl))
                val results = geoJson.optJSONArray("results")
                if (results == null || results.length() == 0) {
                    return@withContext JarvisCommandOutput(
                        englishText = "Sorry $userName, I couldn't find weather data for \"$city\". Please check the city name, buddy.",
                        tamilText = "மன்னிக்கவும் $userName, \"$city\" நகரத்திற்கான வானிலை தகவல் கிடைக்கவில்லை.",
                        contextTopic = ConversationTopic.WEATHER,
                        contextLanguage = preferredLang
                    )
                }
                val first = results.getJSONObject(0)
                coords = first.getDouble("latitude") to first.getDouble("longitude")
                cityLabel = first.getString("name")
                region = first.optString("admin1").ifBlank { null }
                country = first.optString("country").ifBlank { null }
            } else {
                if (!hasLocationPermission) {
                    return@withContext JarvisCommandOutput(
                        englishText = "Location permission is not enabled, $userName. Please specify a city name, like \"What's the weather in Chennai?\"",
                        tamilText = "லொகேஷன் அனுமதி இல்லை $userName. நகரத்தின் பெயரைச் சொல்லுங்கள் buddy—உதாரணமாக \"Chennai weather\".",
                        contextTopic = ConversationTopic.WEATHER,
                        contextLanguage = preferredLang
                    )
                }
                val loc = getLastKnownDeviceLocation()
                    ?: return@withContext JarvisCommandOutput(
                        englishText = "I couldn't read your device location right now, $userName. Please mention a city name like Chennai.",
                        tamilText = "தற்போது இருப்பிடத்தைக் கண்டறிய முடியவில்லை $userName. நகரத்தின் பெயரைச் சொல்லுங்கள் buddy.",
                        contextTopic = ConversationTopic.WEATHER,
                        contextLanguage = preferredLang
                    )
                coords = loc.latitude to loc.longitude
                cityLabel = "Current Location"
            }

            val forecastUrl =
                "https://api.open-meteo.com/v1/forecast?latitude=${coords.first}&longitude=${coords.second}&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m,is_day&daily=weather_code,temperature_2m_max,precipitation_probability_max,wind_speed_10m_max&forecast_days=3&timezone=auto"
            val forecastJson = JSONObject(httpGet(forecastUrl))
            val current = forecastJson.getJSONObject("current")
            val daily = forecastJson.optJSONObject("daily")

            val useFuture = dayOffset >= 1 && daily != null && daily.optJSONArray("temperature_2m_max")?.length() ?: 0 > dayOffset
            val tempC = if (useFuture) {
                kotlin.math.round(daily!!.getJSONArray("temperature_2m_max").getDouble(dayOffset)).toInt()
            } else {
                kotlin.math.round(current.getDouble("temperature_2m")).toInt()
            }
            val humidity = kotlin.math.round(current.optDouble("relative_humidity_2m", 60.0)).toInt()
            val wind = if (useFuture) {
                kotlin.math.round(daily!!.optJSONArray("wind_speed_10m_max")?.optDouble(dayOffset, 10.0) ?: 10.0).toInt()
            } else {
                kotlin.math.round(current.optDouble("wind_speed_10m", 0.0)).toInt()
            }
            val code = if (useFuture) {
                daily!!.optJSONArray("weather_code")?.optInt(dayOffset, 0) ?: 0
            } else {
                current.optInt("weather_code", 0)
            }

            val (condEn, condTa, willRain) = mapWmoCode(code)
            val fDay = when (dayOffset) {
                2 -> "day_after"
                1 -> "tomorrow"
                else -> "today"
            }
            val fLabel = when (dayOffset) {
                2 -> "Day After Tomorrow"
                1 -> "Tomorrow"
                else -> "Today"
            }

            val weather = WeatherData(
                city = cityLabel,
                region = region,
                country = country,
                temperatureC = tempC,
                forecastDay = fDay,
                forecastLabel = fLabel,
                humidity = humidity,
                windSpeedKmh = wind,
                conditionEn = condEn,
                conditionTa = condTa,
                willRain = willRain,
                updatedAt = if (useFuture) "$fLabel forecast" else SimpleDateFormat("h:mm a", Locale.US).format(Date())
            )

            val en = when {
                useFuture && preferredLang == "tanglish" ->
                    "${if (dayOffset == 2) "Naalai marunaal" else "Naalaiku"} $cityLabel weather $condEn irukum buddy — around ${tempC}°C, humidity $humidity%, wind $wind km/h."
                useFuture ->
                    "$fLabel in $cityLabel, expect $condEn around ${tempC}°C, humidity $humidity%, and wind $wind km/h."
                lower.contains("rain") || lower.contains("mazhai") || lower.contains("மழை") ->
                    if (willRain) "Yes buddy, rain is reported in $cityLabel ($condEn). Temperature is ${tempC}°C, humidity $humidity%, wind $wind km/h."
                    else "No rain right now in $cityLabel, $userName. It's $condEn at ${tempC}°C with $humidity% humidity."
                preferredLang == "tanglish" ->
                    "$cityLabel weather ippo ${tempC}°C, $condEn iruku buddy! Humidity $humidity%, wind $wind km/h."
                else ->
                    "Weather in $cityLabel, $userName: ${tempC}°C and $condEn, with $humidity% humidity and $wind km/h wind."
            }
            val taPrefix = when (dayOffset) {
                2 -> "நாளை மறுநாள் "
                1 -> "நாளை "
                else -> ""
            }
            val ta = "$taPrefix$cityLabel வானிலை: வெப்பநிலை ${tempC}°C, $condTa. ஈரப்பதம் $humidity%, காற்று $wind km/h."

            JarvisCommandOutput(
                englishText = en,
                tamilText = ta,
                weather = weather,
                contextTopic = ConversationTopic.WEATHER,
                contextEntityCity = cityLabel,
                contextLanguage = preferredLang
            )
        } catch (_: Exception) {
            JarvisCommandOutput(
                englishText = "Sorry $userName, I couldn't retrieve live weather data right now. Please try again shortly.",
                tamilText = "மன்னிக்கவும் $userName, தற்போது வானிலை தகவலைப் பெற முடியவில்லை.",
                contextTopic = ConversationTopic.WEATHER,
                contextLanguage = preferredLang
            )
        }
    }

    @SuppressLint("MissingPermission")
    private fun getLastKnownDeviceLocation(): Location? {
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return null
        val providers = lm.getProviders(true)
        var best: Location? = null
        for (p in providers) {
            val l = runCatching { lm.getLastKnownLocation(p) }.getOrNull() ?: continue
            if (best == null || l.accuracy < best.accuracy) {
                best = l
            }
        }
        return best
    }

    private fun extractCityFromWeatherQuery(query: String): String? {
        val stopWords = setOf(
            "what", "whats", "what's", "how", "is", "the", "weather", "today", "now", "in", "at",
            "for", "jarvis", "innaiku", "inniku", "epdi", "eppadi", "iruku", "irukku", "enna",
            "mazhai", "peyyuma", "rain", "raining", "forecast", "temperature", "la"
        )
        val prep = Regex("\\b(?:in|at|for)\\s+([a-zA-Z\\s-]{2,40})", RegexOption.IGNORE_CASE).find(query)
        val candidateRaw = prep?.groupValues?.getOrNull(1) ?: query
        val words = candidateRaw.replace(Regex("[?!.,]"), " ")
            .trim()
            .split(Regex("\\s+"))
            .map { it.replace(Regex("-la$", RegexOption.IGNORE_CASE), "") }
            .filter { it.isNotBlank() && it.lowercase(Locale.ROOT) !in stopWords }
        val result = words.joinToString(" ").trim()
        return if (result.length >= 2) result else null
    }

    private fun mapWmoCode(code: Int): Triple<String, String, Boolean> = when (code) {
        0 -> Triple("Clear sky", "தெளிவான வானம்", false)
        1, 2 -> Triple("Partly cloudy", "பகுதி மேகமூட்டம்", false)
        3 -> Triple("Overcast clouds", "முழு மேகமூட்டம்", false)
        45, 48 -> Triple("Foggy", "பனிமூட்டம்", false)
        in 51..67, in 80..82 -> Triple("Rainy", "மழை பெய்கிறது", true)
        in 95..99 -> Triple("Thunderstorm", "இடி மின்னலுடன் மழை", true)
        else -> Triple("Clear", "இதமான வானிலை", false)
    }

    private fun httpGet(urlStr: String): String {
        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 7000
            readTimeout = 7000
        }
        return conn.inputStream.bufferedReader().use { it.readText() }
    }
}
