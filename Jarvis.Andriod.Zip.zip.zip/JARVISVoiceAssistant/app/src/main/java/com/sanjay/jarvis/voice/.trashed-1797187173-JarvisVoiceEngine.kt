package com.sanjay.jarvis.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.sanjay.jarvis.model.LanguageMode
import java.util.Locale
import java.util.UUID

data class DeviceVoiceOption(
    val name: String,
    val localeTag: String,
    val isMaleLikely: Boolean,
    val isNetwork: Boolean
)

/**
 * Single-instance, leak-free SpeechRecognizer and TextToSpeech controller for Android.
 * Enforces no auto-restart loops on error or completion.
 */
class JarvisVoiceEngine(private val context: Context) {

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var activeRecognizer: SpeechRecognizer? = null

    @Volatile
    private var isListening = false

    private var installedVoices: List<Voice> = emptyList()
    private var onVoicesUpdated: ((List<DeviceVoiceOption>) -> Unit)? = null

    fun initializeTts(onReady: ((List<DeviceVoiceOption>) -> Unit)? = null) {
        onVoicesUpdated = onReady
        if (tts != null) {
            if (ttsReady) onReady?.invoke(getAvailableVoices())
            return
        }
        tts = TextToSpeech(context.applicationContext) { status ->
            ttsReady = (status == TextToSpeech.SUCCESS)
            if (ttsReady) {
                installedVoices = tts?.voices?.toList().orEmpty()
                onVoicesUpdated?.invoke(getAvailableVoices())
            }
        }
    }

    fun getAvailableVoices(): List<DeviceVoiceOption> {
        val maleMarkers = listOf("male", "guy", "daniel", "arthur", "ryan", "rishi", "prabhat", "valluvar", "iol")
        return installedVoices
            .sortedWith(
                compareByDescending<Voice> { v ->
                    val n = v.name.lowercase(Locale.ROOT)
                    maleMarkers.any { n.contains(it) }
                }.thenBy { it.locale.language }
            )
            .map { voice ->
                val lower = voice.name.lowercase(Locale.ROOT)
                DeviceVoiceOption(
                    name = voice.name,
                    localeTag = voice.locale.toLanguageTag(),
                    isMaleLikely = maleMarkers.any { lower.contains(it) },
                    isNetwork = voice.isNetworkConnectionRequired
                )
            }
    }

    fun resolvePreferredVoiceName(savedName: String?): String {
        if (!savedName.isNullOrBlank()) {
            val exact = installedVoices.firstOrNull { it.name == savedName }
            if (exact != null) return exact.name
        }
        return getAvailableVoices().firstOrNull()?.name ?: "System Default"
    }

    fun speak(
        englishText: String,
        tamilText: String? = null,
        languageMode: LanguageMode,
        selectedVoiceName: String?,
        rate: Float,
        pitch: Float,
        onComplete: () -> Unit = {}
    ) {
        val engine = tts
        if (engine == null || !ttsReady) {
            onComplete()
            return
        }

        engine.setSpeechRate(rate.coerceIn(0.75f, 1.3f))
        engine.setPitch(pitch.coerceIn(0.65f, 1.25f))

        val utteranceId = UUID.randomUUID().toString()
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) {
                if (id == utteranceId) onComplete()
            }

            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) {
                if (id == utteranceId) onComplete()
            }
        })

        val textToSpeak = when (languageMode) {
            LanguageMode.ENGLISH -> englishText
            LanguageMode.TAMIL -> tamilText ?: englishText
            LanguageMode.BILINGUAL -> if (!tamilText.isNullOrBlank() && tamilText != englishText) {
                "$englishText $tamilText"
            } else {
                englishText
            }
        }

        val chosenVoice = if (!selectedVoiceName.isNullOrBlank()) {
            installedVoices.firstOrNull { it.name == selectedVoiceName }
        } else {
            val preferredName = getAvailableVoices().firstOrNull()?.name
            installedVoices.firstOrNull { it.name == preferredName }
        }

        if (chosenVoice != null) {
            engine.voice = chosenVoice
        } else {
            engine.language = if (languageMode == LanguageMode.TAMIL) Locale("ta", "IN") else Locale.US
        }

        engine.speak(textToSpeak, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun stopSpeaking() {
        tts?.stop()
    }

    fun startListening(
        languageMode: LanguageMode,
        onInterim: (String) -> Unit,
        onResult: (String) -> Unit,
        onError: (String) -> Unit,
        onEnd: () -> Unit
    ) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onError("Speech recognition service is unavailable on this device.")
            return
        }

        // Prevent multiple simultaneous recognizers
        stopListening()

        val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
        activeRecognizer = recognizer
        isListening = true

        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                isListening = false
            }

            override fun onError(error: Int) {
                isListening = false
                destroyActiveRecognizer()
                val message = when (error) {
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                        "Microphone permission denied. Please grant Microphone access in Android Settings."
                    SpeechRecognizer.ERROR_NO_MATCH ->
                        "No speech detected. Tap the Arc Reactor and try again."
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                        "Listening timed out. Tap the microphone when ready."
                    SpeechRecognizer.ERROR_AUDIO ->
                        "Microphone audio capture failed."
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                        "Speech network unavailable right now."
                    else -> "Speech recognition stopped (code $error)."
                }
                onError(message)
                // Critical: Never auto-restart on error
            }

            override fun onResults(results: Bundle?) {
                isListening = false
                destroyActiveRecognizer()
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val finalTranscript = matches?.firstOrNull()?.trim().orEmpty()
                if (finalTranscript.isNotEmpty()) {
                    onResult(finalTranscript)
                } else {
                    onEnd()
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val partial = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    ?.trim()
                if (!partial.isNullOrEmpty()) {
                    onInterim(partial)
                }
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE,
                if (languageMode == LanguageMode.TAMIL) "ta-IN" else "en-IN"
            )
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }

        recognizer.startListening(intent)
    }

    fun stopListening() {
        isListening = false
        destroyActiveRecognizer()
    }

    private fun destroyActiveRecognizer() {
        activeRecognizer?.let { rec ->
            runCatching { rec.cancel() }
            runCatching { rec.destroy() }
        }
        activeRecognizer = null
    }

    fun shutdown() {
        stopListening()
        tts?.stop()
        tts?.shutdown()
        tts = null
        ttsReady = false
    }
}
