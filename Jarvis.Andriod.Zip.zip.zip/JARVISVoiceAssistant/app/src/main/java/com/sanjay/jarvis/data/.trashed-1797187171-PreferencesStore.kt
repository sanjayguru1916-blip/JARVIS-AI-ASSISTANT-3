package com.sanjay.jarvis.data

import android.content.Context
import android.content.SharedPreferences
import com.sanjay.jarvis.model.AiBrainPrefs
import com.sanjay.jarvis.model.ConversationTopic
import com.sanjay.jarvis.model.HologramThemeId
import com.sanjay.jarvis.model.JarvisMessage
import com.sanjay.jarvis.model.JarvisSettings
import com.sanjay.jarvis.model.JarvisTask
import com.sanjay.jarvis.model.LanguageMode
import com.sanjay.jarvis.model.SmartMemoryItem
import com.sanjay.jarvis.model.TaskPriority
import com.sanjay.jarvis.model.TaskStatus
import com.sanjay.jarvis.model.WhatsAppNotificationPrefs
import com.sanjay.jarvis.model.WhatsAppPrivacyMode
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

class PreferencesStore(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun loadSettings(): JarvisSettings {
        val lang = runCatching {
            LanguageMode.valueOf(prefs.getString(KEY_LANG, LanguageMode.BILINGUAL.name)!!)
        }.getOrDefault(LanguageMode.BILINGUAL)

        val theme = runCatching {
            HologramThemeId.valueOf(prefs.getString(KEY_THEME, HologramThemeId.CLASSIC_BLUE.name)!!)
        }.getOrDefault(HologramThemeId.CLASSIC_BLUE)

        val waMode = runCatching {
            WhatsAppPrivacyMode.valueOf(
                prefs.getString(KEY_WA_PRIVACY_MODE, WhatsAppPrivacyMode.PRIVACY.name)!!
            )
        }.getOrDefault(WhatsAppPrivacyMode.PRIVACY)

        return JarvisSettings(
            userName = prefs.getString(KEY_USER_NAME, "Sanjay") ?: "Sanjay",
            languageMode = lang,
            speechRate = prefs.getFloat(KEY_SPEECH_RATE, 1.0f),
            speechPitch = prefs.getFloat(KEY_SPEECH_PITCH, 0.88f),
            selectedVoiceName = prefs.getString(KEY_VOICE_NAME, null),
            wakeWordEnabled = false, // Always explicit opt-in per session
            continuousListeningEnabled = prefs.getBoolean(KEY_CONTINUOUS, false),
            taskRemindersEnabled = prefs.getBoolean(KEY_TASK_REMINDERS, true),
            isMuted = prefs.getBoolean(KEY_MUTED, false),
            themeId = theme,
            whatsappPrefs = WhatsAppNotificationPrefs(
                enabled = prefs.getBoolean(KEY_WA_ENABLED, false),
                consentAccepted = prefs.getBoolean(KEY_WA_CONSENT, false),
                privacyMode = waMode,
                allowSensitiveOnLockScreen = prefs.getBoolean(KEY_WA_LOCK_SCREEN, false)
            ),
            aiBrainPrefs = AiBrainPrefs(
                enabled = prefs.getBoolean(KEY_AI_ENABLED, true),
                smartMemoryEnabled = prefs.getBoolean(KEY_AI_MEMORY_ENABLED, false),
                smartMemoryConsentAccepted = prefs.getBoolean(KEY_AI_MEMORY_CONSENT, false),
                backendBaseUrl = prefs.getString(KEY_AI_BACKEND_URL, "") ?: ""
            )
        )
    }

    fun saveSettings(settings: JarvisSettings) {
        prefs.edit()
            .putString(KEY_USER_NAME, settings.userName)
            .putString(KEY_LANG, settings.languageMode.name)
            .putFloat(KEY_SPEECH_RATE, settings.speechRate)
            .putFloat(KEY_SPEECH_PITCH, settings.speechPitch)
            .putString(KEY_VOICE_NAME, settings.selectedVoiceName)
            .putBoolean(KEY_CONTINUOUS, settings.continuousListeningEnabled)
            .putBoolean(KEY_TASK_REMINDERS, settings.taskRemindersEnabled)
            .putBoolean(KEY_MUTED, settings.isMuted)
            .putString(KEY_THEME, settings.themeId.name)
            .putBoolean(KEY_WA_ENABLED, settings.whatsappPrefs.enabled)
            .putBoolean(KEY_WA_CONSENT, settings.whatsappPrefs.consentAccepted)
            .putString(KEY_WA_PRIVACY_MODE, settings.whatsappPrefs.privacyMode.name)
            .putBoolean(KEY_WA_LOCK_SCREEN, settings.whatsappPrefs.allowSensitiveOnLockScreen)
            .putBoolean(KEY_AI_ENABLED, settings.aiBrainPrefs.enabled)
            .putBoolean(KEY_AI_MEMORY_ENABLED, settings.aiBrainPrefs.smartMemoryEnabled)
            .putBoolean(KEY_AI_MEMORY_CONSENT, settings.aiBrainPrefs.smartMemoryConsentAccepted)
            .putString(KEY_AI_BACKEND_URL, settings.aiBrainPrefs.backendBaseUrl)
            .apply()
    }

    fun loadMemories(): List<SmartMemoryItem> {
        val raw = prefs.getString(KEY_AI_MEMORIES_JSON, null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    add(
                        SmartMemoryItem(
                            id = obj.getString("id"),
                            label = obj.getString("label"),
                            value = obj.getString("value")
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    fun saveMemories(memories: List<SmartMemoryItem>) {
        val arr = JSONArray()
        memories.forEach { m ->
            arr.put(JSONObject().apply {
                put("id", m.id)
                put("label", m.label)
                put("value", m.value)
            })
        }
        prefs.edit().putString(KEY_AI_MEMORIES_JSON, arr.toString()).apply()
    }

    fun loadHistory(): List<JarvisMessage> {
        val raw = prefs.getString(KEY_HISTORY_JSON, null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val topicStr = obj.optString("contextTopic", "")
                    val topic = if (topicStr.isNotBlank()) {
                        runCatching { ConversationTopic.valueOf(topicStr) }.getOrNull()
                    } else null
                    add(
                        JarvisMessage(
                            id = obj.getString("id"),
                            isJarvis = obj.getBoolean("isJarvis"),
                            text = obj.getString("text"),
                            tamilText = obj.optString("tamilText", "").ifBlank { null },
                            timestamp = obj.optString("timestamp", ""),
                            createdAtMillis = obj.optLong("createdAtMillis", System.currentTimeMillis()),
                            usedExternalAi = obj.optBoolean("usedExternalAi", false),
                            contextTopic = topic,
                            contextEntityCity = obj.optString("contextEntityCity", "").ifBlank { null },
                            contextLanguage = obj.optString("contextLanguage", "").ifBlank { null }
                        )
                    )
                }
            }.takeLast(40)
        }.getOrDefault(emptyList())
    }

    fun saveHistory(messages: List<JarvisMessage>) {
        val arr = JSONArray()
        messages.takeLast(40).forEach { msg ->
            arr.put(JSONObject().apply {
                put("id", msg.id)
                put("isJarvis", msg.isJarvis)
                put("text", msg.text)
                put("tamilText", msg.tamilText ?: "")
                put("timestamp", msg.timestamp)
                put("createdAtMillis", msg.createdAtMillis)
                put("usedExternalAi", msg.usedExternalAi)
                put("contextTopic", msg.contextTopic?.name ?: "")
                put("contextEntityCity", msg.contextEntityCity ?: "")
                put("contextLanguage", msg.contextLanguage ?: "")
            })
        }
        prefs.edit().putString(KEY_HISTORY_JSON, arr.toString()).apply()
    }

    fun clearHistory() {
        prefs.edit().remove(KEY_HISTORY_JSON).apply()
    }

    fun loadTasks(): List<JarvisTask> {
        val raw = prefs.getString(KEY_TASKS_JSON, null)
        if (raw == null) {
            val starter = defaultStarterTasks()
            saveTasks(starter)
            return starter
        }
        return runCatching {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    add(
                        JarvisTask(
                            id = obj.getString("id"),
                            title = obj.getString("title"),
                            description = obj.optString("description", ""),
                            dueDate = obj.optString("dueDate", "").ifBlank { null },
                            dueTime = obj.optString("dueTime", "").ifBlank { null },
                            priority = runCatching {
                                TaskPriority.valueOf(obj.optString("priority", "MEDIUM"))
                            }.getOrDefault(TaskPriority.MEDIUM),
                            reminderEnabled = obj.optBoolean("reminderEnabled", true),
                            status = runCatching {
                                TaskStatus.valueOf(obj.optString("status", "PENDING"))
                            }.getOrDefault(TaskStatus.PENDING),
                            createdAtMillis = obj.optLong("createdAtMillis", System.currentTimeMillis()),
                            notifiedAtMillis = if (obj.has("notifiedAtMillis") && !obj.isNull("notifiedAtMillis")) {
                                obj.getLong("notifiedAtMillis")
                            } else {
                                null
                            }
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    fun saveTasks(tasks: List<JarvisTask>) {
        val arr = JSONArray()
        tasks.forEach { task ->
            val obj = JSONObject().apply {
                put("id", task.id)
                put("title", task.title)
                put("description", task.description)
                put("dueDate", task.dueDate ?: "")
                put("dueTime", task.dueTime ?: "")
                put("priority", task.priority.name)
                put("reminderEnabled", task.reminderEnabled)
                put("status", task.status.name)
                put("createdAtMillis", task.createdAtMillis)
                if (task.notifiedAtMillis != null) {
                    put("notifiedAtMillis", task.notifiedAtMillis)
                } else {
                    put("notifiedAtMillis", JSONObject.NULL)
                }
            }
            arr.put(obj)
        }
        prefs.edit().putString(KEY_TASKS_JSON, arr.toString()).apply()
    }

    private fun defaultStarterTasks(): List<JarvisTask> {
        val today = LocalDate.now().toString()
        val tomorrow = LocalDate.now().plusDays(1).toString()
        return listOf(
            JarvisTask(
                id = "starter-groceries",
                title = "Buy groceries",
                description = "Fresh fruits, milk, and filter coffee",
                dueDate = today,
                dueTime = "20:30",
                priority = TaskPriority.MEDIUM,
                reminderEnabled = false,
                status = TaskStatus.PENDING
            ),
            JarvisTask(
                id = "starter-schedule",
                title = "Review AI assistant schedule",
                description = "Verify reminders and priority directives",
                dueDate = tomorrow,
                dueTime = "10:00",
                priority = TaskPriority.HIGH,
                reminderEnabled = false,
                status = TaskStatus.PENDING
            )
        )
    }

    companion object {
        private const val PREFS_NAME = "jarvis_android_local_prefs_v1"
        private const val KEY_USER_NAME = "user_name"
        private const val KEY_LANG = "language_mode"
        private const val KEY_SPEECH_RATE = "speech_rate"
        private const val KEY_SPEECH_PITCH = "speech_pitch"
        private const val KEY_VOICE_NAME = "selected_voice_name"
        private const val KEY_CONTINUOUS = "continuous_listening"
        private const val KEY_TASK_REMINDERS = "task_reminders_enabled"
        private const val KEY_MUTED = "is_muted"
        private const val KEY_THEME = "hologram_theme"
        private const val KEY_WA_ENABLED = "wa_assistant_enabled"
        private const val KEY_WA_CONSENT = "wa_user_consent"
        private const val KEY_WA_PRIVACY_MODE = "wa_privacy_mode"
        private const val KEY_WA_LOCK_SCREEN = "wa_lock_screen_sensitive"
        private const val KEY_AI_ENABLED = "ai_brain_enabled"
        private const val KEY_AI_MEMORY_ENABLED = "ai_memory_enabled"
        private const val KEY_AI_MEMORY_CONSENT = "ai_memory_consent"
        private const val KEY_AI_BACKEND_URL = "ai_backend_base_url"
        private const val KEY_AI_MEMORIES_JSON = "ai_smart_memories_json"
        private const val KEY_HISTORY_JSON = "conversation_history_json"
        private const val KEY_TASKS_JSON = "tasks_json"
    }
}
