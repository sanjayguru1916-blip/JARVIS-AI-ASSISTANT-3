package com.sanjay.jarvis.model

import androidx.compose.ui.graphics.Color

enum class LanguageMode(val label: String) {
    BILINGUAL("Bilingual"),
    ENGLISH("English"),
    TAMIL("தமிழ்")
}

enum class AssistantState {
    IDLE,
    LISTENING,
    PROCESSING,
    SPEAKING,
    WAKE_DETECTED
}

enum class HologramThemeId(val displayName: String, val shortName: String) {
    CLASSIC_BLUE("Classic JARVIS Blue", "JARVIS Blue"),
    MATRIX_GREEN("Matrix Green", "Matrix Green"),
    IRON_RED("Iron Red Alert", "Iron Red"),
    CYBER_PURPLE("Cyber Purple", "Cyber Purple")
}

data class HologramThemePalette(
    val id: HologramThemeId,
    val primary: Color,
    val bright: Color,
    val softSurface: Color,
    val border: Color,
    val badgeBg: Color,
    val onAccentText: Color
)

object HologramThemes {
    val palettes: Map<HologramThemeId, HologramThemePalette> = mapOf(
        HologramThemeId.CLASSIC_BLUE to HologramThemePalette(
            id = HologramThemeId.CLASSIC_BLUE,
            primary = Color(0xFF06B6D4),
            bright = Color(0xFF22D3EE),
            softSurface = Color(0x66083344),
            border = Color(0x5906B6D4),
            badgeBg = Color(0xCC083344),
            onAccentText = Color(0xFF020617)
        ),
        HologramThemeId.MATRIX_GREEN to HologramThemePalette(
            id = HologramThemeId.MATRIX_GREEN,
            primary = Color(0xFF10B981),
            bright = Color(0xFF34D399),
            softSurface = Color(0x66022C22),
            border = Color(0x5910B981),
            badgeBg = Color(0xCC022C22),
            onAccentText = Color(0xFF020617)
        ),
        HologramThemeId.IRON_RED to HologramThemePalette(
            id = HologramThemeId.IRON_RED,
            primary = Color(0xFFEF4444),
            bright = Color(0xFFF87171),
            softSurface = Color(0x66450A0A),
            border = Color(0x66EF4444),
            badgeBg = Color(0xCC450A0A),
            onAccentText = Color.White
        ),
        HologramThemeId.CYBER_PURPLE to HologramThemePalette(
            id = HologramThemeId.CYBER_PURPLE,
            primary = Color(0xFFA855F7),
            bright = Color(0xFFC084FC),
            softSurface = Color(0x663B0764),
            border = Color(0x66A855F7),
            badgeBg = Color(0xCC3B0764),
            onAccentText = Color.White
        )
    )

    fun get(id: HologramThemeId): HologramThemePalette =
        palettes[id] ?: palettes.getValue(HologramThemeId.CLASSIC_BLUE)
}

enum class TaskPriority(val label: String) {
    HIGH("High"),
    MEDIUM("Medium"),
    LOW("Low")
}

enum class TaskStatus {
    PENDING,
    COMPLETED
}

data class JarvisTask(
    val id: String,
    val title: String,
    val description: String = "",
    val dueDate: String? = null, // YYYY-MM-DD
    val dueTime: String? = null, // HH:MM (24h)
    val priority: TaskPriority = TaskPriority.MEDIUM,
    val reminderEnabled: Boolean = true,
    val status: TaskStatus = TaskStatus.PENDING,
    val createdAtMillis: Long = System.currentTimeMillis(),
    val notifiedAtMillis: Long? = null
)

data class PendingTaskDraft(
    val title: String,
    val dueDate: String? = null,
    val dueTime: String? = null,
    val priority: TaskPriority = TaskPriority.MEDIUM,
    val reminderEnabled: Boolean = true,
    val clarificationReason: String = "time"
)

data class WeatherData(
    val city: String,
    val region: String? = null,
    val country: String? = null,
    val temperatureC: Int,
    val forecastDay: String = "today",
    val forecastLabel: String = "Today",
    val humidity: Int,
    val windSpeedKmh: Int,
    val conditionEn: String,
    val conditionTa: String,
    val willRain: Boolean,
    val updatedAt: String
)

enum class WhatsAppPrivacyMode(val title: String, val description: String) {
    PRIVACY(
        "Privacy Mode",
        "Announce only: \"You have a new WhatsApp message.\""
    ),
    READ(
        "Read Mode",
        "Reads sender name and message aloud locally on device."
    )
}

data class WhatsAppNotificationPrefs(
    val enabled: Boolean = false,
    val consentAccepted: Boolean = false,
    val privacyMode: WhatsAppPrivacyMode = WhatsAppPrivacyMode.PRIVACY,
    val allowSensitiveOnLockScreen: Boolean = false
)

data class SmartMemoryItem(
    val id: String,
    val label: String,
    val value: String
)

data class AiBrainPrefs(
    val enabled: Boolean = true,
    val smartMemoryEnabled: Boolean = false,
    val smartMemoryConsentAccepted: Boolean = false,
    val backendBaseUrl: String = ""
)

data class JarvisSettings(
    val userName: String = "Sanjay",
    val languageMode: LanguageMode = LanguageMode.BILINGUAL,
    val speechRate: Float = 1.0f,
    val speechPitch: Float = 0.88f,
    val selectedVoiceName: String? = null,
    val wakeWordEnabled: Boolean = false,
    val continuousListeningEnabled: Boolean = false,
    val taskRemindersEnabled: Boolean = true,
    val isMuted: Boolean = false,
    val themeId: HologramThemeId = HologramThemeId.CLASSIC_BLUE,
    val whatsappPrefs: WhatsAppNotificationPrefs = WhatsAppNotificationPrefs(),
    val aiBrainPrefs: AiBrainPrefs = AiBrainPrefs()
)

enum class ConversationTopic {
    WEATHER,
    TASK,
    BRIEFING,
    BATTERY,
    APP,
    GENERAL
}

data class JarvisMessage(
    val id: String,
    val isJarvis: Boolean,
    val text: String,
    val tamilText: String? = null,
    val timestamp: String,
    val createdAtMillis: Long = System.currentTimeMillis(),
    val weather: WeatherData? = null,
    val taskHighlights: List<JarvisTask> = emptyList(),
    val intentAppPackage: String? = null,
    val intentLabel: String? = null,
    val usedExternalAi: Boolean = false,
    val contextTopic: ConversationTopic? = null,
    val contextEntityCity: String? = null,
    val contextLanguage: String? = null
)
