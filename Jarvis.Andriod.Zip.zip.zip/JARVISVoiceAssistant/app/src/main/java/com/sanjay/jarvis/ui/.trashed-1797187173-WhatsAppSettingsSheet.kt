package com.sanjay.jarvis.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sanjay.jarvis.model.*
import com.sanjay.jarvis.service.WhatsAppNotificationListenerService
import com.sanjay.jarvis.voice.DeviceVoiceOption

@Composable
fun JarvisSettingsDialog(
    settings: JarvisSettings,
    palette: HologramThemePalette,
    availableVoices: List<DeviceVoiceOption>,
    activeVoiceName: String,
    notificationAccessGranted: Boolean,
    postNotificationsGranted: Boolean,
    savedMemories: List<SmartMemoryItem>,
    onUpdateMemories: (List<SmartMemoryItem>) -> Unit,
    onClearSessionContext: () -> Unit,
    onRequestPostNotificationPermission: () -> Unit,
    onRefreshPermissions: () -> Unit,
    onTestSelectedVoice: () -> Unit,
    onTestWhatsAppAnnouncement: (String) -> Unit,
    onSave: (JarvisSettings) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var draft by remember(settings) { mutableStateOf(settings) }
    var showConsentDialog by remember { mutableStateOf(false) }
    var showAiMemoryConsentDialog by remember { mutableStateOf(false) }
    var newMemoryLabel by remember { mutableStateOf("") }
    var newMemoryValue by remember { mutableStateOf("") }
    var permissionError by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF0F172A),
        titleContentColor = palette.bright,
        textContentColor = Color(0xFFE2E8F0),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Settings, contentDescription = null, tint = palette.bright)
                Text("JARVIS Settings & Privacy", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 520.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // 1. Hologram Theme Switcher
                Text("Hologram Theme", fontSize = 12.sp, color = palette.bright, fontWeight = FontWeight.Medium)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    HologramThemeId.entries.forEach { themeId ->
                        val t = HologramThemes.get(themeId)
                        val selected = draft.themeId == themeId
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { draft = draft.copy(themeId = themeId) },
                            shape = RoundedCornerShape(10.dp),
                            color = if (selected) t.softSurface else Color(0xFF020617),
                            border = BorderStroke(1.dp, if (selected) t.bright else Color(0xFF1E293B))
                        ) {
                            Text(
                                text = t.id.shortName.replace("JARVIS ", ""),
                                fontSize = 10.sp,
                                color = if (selected) t.bright else Color(0xFF94A3B8),
                                modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
                                maxLines = 1
                            )
                        }
                    }
                }

                HorizontalDivider(color = Color(0xFF1E293B))

                // 2. Voice Selection & Test
                Text("Voice Settings ($activeVoiceName)", fontSize = 12.sp, color = palette.bright, fontWeight = FontWeight.Medium)
                if (availableVoices.isNotEmpty()) {
                    var expanded by remember { mutableStateOf(false) }
                    Box {
                        OutlinedButton(
                            onClick = { expanded = true },
                            modifier = Modifier.fillMaxWidth(),
                            border = BorderStroke(1.dp, palette.border)
                        ) {
                            Text(
                                text = draft.selectedVoiceName ?: activeVoiceName,
                                color = Color.White,
                                fontSize = 12.sp,
                                maxLines = 1
                            )
                        }
                        DropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false }
                        ) {
                            availableVoices.take(20).forEach { voice ->
                                DropdownMenuItem(
                                    text = {
                                        Text("${voice.name} (${voice.localeTag})${if (voice.isMaleLikely) " • Male" else ""}", fontSize = 12.sp)
                                    },
                                    onClick = {
                                        draft = draft.copy(selectedVoiceName = voice.name)
                                        expanded = false
                                    }
                                )
                            }
                        }
                    }
                }
                Button(
                    onClick = onTestSelectedVoice,
                    colors = ButtonDefaults.buttonColors(containerColor = palette.primary, contentColor = palette.onAccentText),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Test Selected Voice", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }

                HorizontalDivider(color = Color(0xFF1E293B))

                // 3. WhatsApp Notification Assistant (NotificationListenerService)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = palette.bright, modifier = Modifier.size(18.dp))
                    Text("WhatsApp Notification Assistant", fontSize = 13.sp, color = palette.bright, fontWeight = FontWeight.SemiBold)
                }

                Text(
                    "Optional local assistant using Android NotificationListenerService. Message text stays 100% on-device and WhatsApp chats are never accessed directly.",
                    fontSize = 11.sp,
                    color = Color(0xFF94A3B8),
                    lineHeight = 15.sp
                )

                // Master Switch with mandatory User Consent
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF020617), RoundedCornerShape(12.dp))
                        .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("WhatsApp Announcements", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = Color.White)
                        Text(
                            if (draft.whatsappPrefs.enabled) "Active · Local TTS only" else "Disabled (Opt-in required)",
                            fontSize = 10.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                    Switch(
                        checked = draft.whatsappPrefs.enabled,
                        onCheckedChange = { wantEnable ->
                            permissionError = null
                            if (wantEnable && !draft.whatsappPrefs.consentAccepted) {
                                showConsentDialog = true
                            } else {
                                draft = draft.copy(
                                    whatsappPrefs = draft.whatsappPrefs.copy(enabled = wantEnable)
                                )
                            }
                        }
                    )
                }

                // Android Notification Access status & Deep Link
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (notificationAccessGranted) Color(0x33064E3B) else Color(0x3378350F),
                    border = BorderStroke(
                        1.dp,
                        if (notificationAccessGranted) Color(0xFF10B981) else Color(0xFFF59E0B)
                    )
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(
                                if (notificationAccessGranted) Icons.Default.VerifiedUser else Icons.Default.Warning,
                                contentDescription = null,
                                tint = if (notificationAccessGranted) Color(0xFF34D399) else Color(0xFFFBBF24),
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                if (notificationAccessGranted) "Notification Access: Granted" else "Notification Access: Required",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color.White
                            )
                        }
                        if (!notificationAccessGranted) {
                            Text(
                                "1. Tap Open Notification Access below.\n2. Select \"JARVIS Voice Assistant\".\n3. Enable Allow Notification Access and return.",
                                fontSize = 11.sp,
                                color = Color(0xFFE2E8F0)
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = {
                                    runCatching {
                                        val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                                        context.startActivity(intent)
                                    }.onFailure {
                                        permissionError = "Unable to open Android Notification Access settings automatically. Please open Settings > Apps > Special app access > Notification access."
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Open Notification Access", fontSize = 11.sp, color = palette.bright)
                            }
                            TextButton(onClick = onRefreshPermissions) {
                                Text("Refresh", fontSize = 11.sp, color = Color(0xFF94A3B8))
                            }
                        }
                    }
                }

                if (!postNotificationsGranted) {
                    OutlinedButton(
                        onClick = onRequestPostNotificationPermission,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Grant Android Notification Permission (Android 13+)", fontSize = 11.sp, color = Color(0xFFFBBF24))
                    }
                }

                permissionError?.let { err ->
                    Text(err, fontSize = 11.sp, color = Color(0xFFFCA5A5))
                }

                // Privacy Mode vs Read Mode Selector
                Text("Announcement Privacy Mode", fontSize = 12.sp, color = palette.bright, fontWeight = FontWeight.Medium)
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    WhatsAppPrivacyMode.entries.forEach { mode ->
                        val selected = draft.whatsappPrefs.privacyMode == mode
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    draft = draft.copy(
                                        whatsappPrefs = draft.whatsappPrefs.copy(privacyMode = mode)
                                    )
                                },
                            shape = RoundedCornerShape(10.dp),
                            color = if (selected) palette.softSurface else Color(0xFF020617),
                            border = BorderStroke(1.dp, if (selected) palette.bright else Color(0xFF1E293B))
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(mode.title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                                Text(mode.description, fontSize = 10.sp, color = Color(0xFF94A3B8))
                            }
                        }
                    }
                }

                // Lock Screen Protection Switch
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF020617), RoundedCornerShape(12.dp))
                        .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = palette.bright, modifier = Modifier.size(14.dp))
                            Text("Allow Content on Lock Screen", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = Color.White)
                        }
                        Text(
                            if (draft.whatsappPrefs.allowSensitiveOnLockScreen)
                                "Warning: Sender/message can be spoken while locked."
                            else
                                "Protected: Sensitive content hidden when device is locked.",
                            fontSize = 10.sp,
                            color = if (draft.whatsappPrefs.allowSensitiveOnLockScreen) Color(0xFFFBBF24) else Color(0xFF94A3B8)
                        )
                    }
                    Switch(
                        checked = draft.whatsappPrefs.allowSensitiveOnLockScreen,
                        onCheckedChange = { allow ->
                            draft = draft.copy(
                                whatsappPrefs = draft.whatsappPrefs.copy(allowSensitiveOnLockScreen = allow)
                            )
                        }
                    )
                }

                // Test Announcement respecting current mode
                OutlinedButton(
                    onClick = {
                        val sample = if (draft.whatsappPrefs.privacyMode == WhatsAppPrivacyMode.PRIVACY) {
                            "You have a new WhatsApp message."
                        } else {
                            "New WhatsApp message from Kumar: Reaching in 10 minutes."
                        }
                        onTestWhatsAppAnnouncement(sample)
                    },
                    enabled = draft.whatsappPrefs.enabled,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Test Local Announcement", fontSize = 11.sp, color = palette.bright)
                }

                HorizontalDivider(color = Color(0xFF1E293B))

                // Task Reminders & Wake Word toggles
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Task Reminder Alerts", fontSize = 12.sp, color = Color.White)
                    Switch(
                        checked = draft.taskRemindersEnabled,
                        onCheckedChange = { draft = draft.copy(taskRemindersEnabled = it) }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Wake Word Mode ('Hey Jarvis')", fontSize = 12.sp, color = Color.White)
                    Switch(
                        checked = draft.wakeWordEnabled,
                        onCheckedChange = { draft = draft.copy(wakeWordEnabled = it) }
                    )
                }

                HorizontalDivider(color = Color(0xFF1E293B))

                // 4. Advanced AI Brain & Optional Smart Memory
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Default.Psychology, contentDescription = null, tint = palette.bright, modifier = Modifier.size(18.dp))
                    Text("Advanced AI Brain", fontSize = 13.sp, color = palette.bright, fontWeight = FontWeight.SemiBold)
                }

                Text(
                    "Privacy notice: When External AI Brain is enabled and a command needs AI understanding, only your prompt and compact session context (plus consented memories if enabled) are sent to the configured AI backend.",
                    fontSize = 11.sp,
                    color = Color(0xFF94A3B8),
                    lineHeight = 15.sp
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF020617), RoundedCornerShape(12.dp))
                        .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("External AI Conversation", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = Color.White)
                        Text(
                            if (draft.aiBrainPrefs.enabled) "Active · Falls back offline cleanly" else "Local commands only",
                            fontSize = 10.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                    Switch(
                        checked = draft.aiBrainPrefs.enabled,
                        onCheckedChange = {
                            draft = draft.copy(aiBrainPrefs = draft.aiBrainPrefs.copy(enabled = it))
                        }
                    )
                }

                OutlinedTextField(
                    value = draft.aiBrainPrefs.backendBaseUrl,
                    onValueChange = { url ->
                        draft = draft.copy(aiBrainPrefs = draft.aiBrainPrefs.copy(backendBaseUrl = url))
                    },
                    label = { Text("JARVIS AI Backend URL (optional)", fontSize = 11.sp) },
                    placeholder = { Text("https://your-jarvis-backend.run.app", fontSize = 11.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF020617), RoundedCornerShape(12.dp))
                        .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Optional Smart Memory", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = Color.White)
                        Text(
                            if (draft.aiBrainPrefs.smartMemoryEnabled) "Opted-in · Long-term preferences saved" else "Disabled (Session context only)",
                            fontSize = 10.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                    Switch(
                        checked = draft.aiBrainPrefs.smartMemoryEnabled,
                        onCheckedChange = { wantEnable ->
                            if (wantEnable && !draft.aiBrainPrefs.smartMemoryConsentAccepted) {
                                showAiMemoryConsentDialog = true
                            } else {
                                draft = draft.copy(
                                    aiBrainPrefs = draft.aiBrainPrefs.copy(smartMemoryEnabled = wantEnable)
                                )
                            }
                        }
                    )
                }

                OutlinedButton(
                    onClick = onClearSessionContext,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Reset Temporary Session Context", fontSize = 11.sp, color = palette.bright)
                }

                if (draft.aiBrainPrefs.smartMemoryEnabled || savedMemories.isNotEmpty()) {
                    Text("Saved Long-Term Memories (${savedMemories.size})", fontSize = 11.sp, color = palette.bright, fontWeight = FontWeight.Medium)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = newMemoryLabel,
                            onValueChange = { newMemoryLabel = it },
                            placeholder = { Text("Label (e.g. City)", fontSize = 10.sp) },
                            singleLine = true,
                            modifier = Modifier.weight(0.42f)
                        )
                        OutlinedTextField(
                            value = newMemoryValue,
                            onValueChange = { newMemoryValue = it },
                            placeholder = { Text("Preference", fontSize = 10.sp) },
                            singleLine = true,
                            modifier = Modifier.weight(0.58f)
                        )
                    }
                    Button(
                        onClick = {
                            if (newMemoryLabel.isNotBlank() && newMemoryValue.isNotBlank()) {
                                val next = savedMemories + SmartMemoryItem(
                                    id = "mem-${System.currentTimeMillis()}",
                                    label = newMemoryLabel.trim(),
                                    value = newMemoryValue.trim()
                                )
                                onUpdateMemories(next)
                                newMemoryLabel = ""
                                newMemoryValue = ""
                            }
                        },
                        enabled = draft.aiBrainPrefs.smartMemoryEnabled,
                        colors = ButtonDefaults.buttonColors(containerColor = palette.primary, contentColor = palette.onAccentText),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Save Preference Memory", fontSize = 11.sp)
                    }
                    savedMemories.forEach { mem ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF020617), RoundedCornerShape(10.dp))
                                .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(10.dp))
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("${mem.label}: ${mem.value}", fontSize = 11.sp, color = Color(0xFFE2E8F0), modifier = Modifier.weight(1f))
                            IconButton(
                                onClick = { onUpdateMemories(savedMemories.filterNot { it.id == mem.id }) },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete memory", tint = Color(0xFFF87171), modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(draft)
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = palette.primary, contentColor = palette.onAccentText)
            ) {
                Text("Save", fontWeight = FontWeight.SemiBold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Color(0xFF94A3B8))
            }
        }
    )

    // Explicit User Consent Modal before enabling WhatsApp Notification Assistant
    if (showConsentDialog) {
        AlertDialog(
            onDismissRequest = { showConsentDialog = false },
            containerColor = Color(0xFF0F172A),
            titleContentColor = palette.bright,
            textContentColor = Color(0xFFE2E8F0),
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Security, contentDescription = null, tint = palette.bright)
                    Text("Notification Assistant Consent", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Before enabling JARVIS WhatsApp Notification Assistant, please review and confirm:",
                        fontSize = 12.sp,
                        color = Color.White
                    )
                    Text("• Only Android notification banners posted by WhatsApp are read using NotificationListenerService.", fontSize = 11.sp, color = Color(0xFFCBD5E1))
                    Text("• JARVIS never accesses WhatsApp chats, databases, or bypasses WhatsApp security.", fontSize = 11.sp, color = Color(0xFFCBD5E1))
                    Text("• All processing happens locally on your device. No notification content is uploaded or logged externally.", fontSize = 11.sp, color = Color(0xFFCBD5E1))
                    Text("• Sensitive content is not spoken on the lock screen unless you explicitly enable it.", fontSize = 11.sp, color = Color(0xFFCBD5E1))
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        draft = draft.copy(
                            whatsappPrefs = draft.whatsappPrefs.copy(
                                consentAccepted = true,
                                enabled = true
                            )
                        )
                        showConsentDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = palette.primary, contentColor = palette.onAccentText)
                ) {
                    Text("I Consent & Enable")
                }
            },
            dismissButton = {
                TextButton(onClick = { showConsentDialog = false }) {
                    Text("Decline", color = Color(0xFF94A3B8))
                }
            }
        )
    }

    if (showAiMemoryConsentDialog) {
        AlertDialog(
            onDismissRequest = { showAiMemoryConsentDialog = false },
            containerColor = Color(0xFF0F172A),
            titleContentColor = palette.bright,
            textContentColor = Color(0xFFE2E8F0),
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Psychology, contentDescription = null, tint = palette.bright)
                    Text("Smart Memory Consent", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Enable optional long-term Smart Memory?", fontSize = 12.sp, color = Color.White)
                    Text("• Temporary chat context stays only for the active session.", fontSize = 11.sp, color = Color(0xFFCBD5E1))
                    Text("• Long-term memories are stored locally and shared with AI Brain only when Smart Memory is enabled.", fontSize = 11.sp, color = Color(0xFFCBD5E1))
                    Text("• You can view or delete any saved memory anytime in Settings.", fontSize = 11.sp, color = Color(0xFFCBD5E1))
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        draft = draft.copy(
                            aiBrainPrefs = draft.aiBrainPrefs.copy(
                                smartMemoryConsentAccepted = true,
                                smartMemoryEnabled = true
                            )
                        )
                        showAiMemoryConsentDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = palette.primary, contentColor = palette.onAccentText)
                ) {
                    Text("Allow Smart Memory")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAiMemoryConsentDialog = false }) {
                    Text("Cancel", color = Color(0xFF94A3B8))
                }
            }
        )
    }
}
