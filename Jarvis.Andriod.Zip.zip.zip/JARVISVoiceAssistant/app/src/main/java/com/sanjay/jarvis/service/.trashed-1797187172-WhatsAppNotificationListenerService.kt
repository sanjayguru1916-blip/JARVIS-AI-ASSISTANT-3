package com.sanjay.jarvis.service

import android.app.KeyguardManager
import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.media.AudioAttributes
import android.os.PowerManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationManagerCompat
import com.sanjay.jarvis.data.PreferencesStore
import com.sanjay.jarvis.model.WhatsAppPrivacyMode
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * Optional, battery-efficient WhatsApp Notification Assistant.
 *
 * Security & Privacy Guarantees:
 * - Processes notifications strictly locally on-device; never uploads message content.
 * - Never accesses WhatsApp databases or private storage, nor bypasses WhatsApp security.
 * - Ignores notifications unless userConsentAccepted == true AND whatsappPrefs.enabled == true.
 * - Automatically masks sensitive sender/content on the lock screen unless explicitly allowed.
 */
class WhatsAppNotificationListenerService : NotificationListenerService() {

    private lateinit var preferencesStore: PreferencesStore
    private var localTts: TextToSpeech? = null

    @Volatile
    private var ttsInitialized = false

    private val recentAnnouncementTimestamps = ConcurrentHashMap<String, Long>()

    override fun onCreate() {
        super.onCreate()
        preferencesStore = PreferencesStore(applicationContext)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return

        // Only observe official WhatsApp and WhatsApp Business notification posts
        if (sbn.packageName !in WHATSAPP_PACKAGES) return

        val settings = preferencesStore.loadSettings()
        val waPrefs = settings.whatsappPrefs

        // Strictly require explicit user consent AND master toggle ON
        if (!waPrefs.consentAccepted || !waPrefs.enabled || settings.isMuted) {
            return
        }

        val notification = sbn.notification ?: return

        // Skip group summary headers, ongoing call/backup bars, and empty notifications
        val flags = notification.flags
        if ((flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        if ((flags and Notification.FLAG_ONGOING_EVENT) != 0) return

        val extras = notification.extras ?: return
        val sender = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val messageText = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()

        if (sender.isEmpty() && messageText.isEmpty()) return

        // Deduplicate burst updates for the same message within 4 seconds
        val now = System.currentTimeMillis()
        val dedupKey = "${sbn.key}|$sender|$messageText"
        val prevTime = recentAnnouncementTimestamps[dedupKey]
        if (prevTime != null && now - prevTime < DEDUP_WINDOW_MS) {
            return
        }
        recentAnnouncementTimestamps[dedupKey] = now
        if (recentAnnouncementTimestamps.size > 30) {
            recentAnnouncementTimestamps.entries.removeIf { now - it.value > 15_000L }
        }

        // Check lock screen state before reading sensitive content
        val isDeviceLocked = isDeviceScreenLocked()
        val canReadSensitiveContent =
            waPrefs.privacyMode == WhatsAppPrivacyMode.READ &&
                (!isDeviceLocked || waPrefs.allowSensitiveOnLockScreen)

        val announcement = if (canReadSensitiveContent && sender.isNotEmpty() && messageText.isNotEmpty()) {
            "New WhatsApp message from $sender: $messageText"
        } else if (canReadSensitiveContent && sender.isNotEmpty()) {
            "New WhatsApp message from $sender."
        } else {
            // Privacy Mode or Lock-screen protection fallback
            "You have a new WhatsApp message."
        }

        speakAnnouncementLocally(
            text = announcement,
            rate = settings.speechRate,
            pitch = settings.speechPitch,
            preferredVoiceName = settings.selectedVoiceName
        )
    }

    private fun isDeviceScreenLocked(): Boolean {
        val keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager
        val locked = keyguardManager?.isKeyguardLocked ?: true
        val screenOff = powerManager?.isInteractive?.not() ?: false
        return locked || screenOff
    }

    private fun speakAnnouncementLocally(
        text: String,
        rate: Float,
        pitch: Float,
        preferredVoiceName: String?
    ) {
        if (localTts == null) {
            localTts = TextToSpeech(applicationContext) { status ->
                ttsInitialized = (status == TextToSpeech.SUCCESS)
                if (ttsInitialized) {
                    dispatchSpeech(text, rate, pitch, preferredVoiceName)
                }
            }
            return
        }
        if (ttsInitialized) {
            dispatchSpeech(text, rate, pitch, preferredVoiceName)
        }
    }

    private fun dispatchSpeech(
        text: String,
        rate: Float,
        pitch: Float,
        preferredVoiceName: String?
    ) {
        val engine = localTts ?: return
        engine.setSpeechRate(rate.coerceIn(0.8f, 1.25f))
        engine.setPitch(pitch.coerceIn(0.7f, 1.2f))
        engine.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
        if (!preferredVoiceName.isNullOrBlank()) {
            val match = engine.voices?.firstOrNull { it.name == preferredVoiceName }
            if (match != null) {
                engine.voice = match
            }
        } else {
            engine.language = Locale.US
        }
        engine.speak(text, TextToSpeech.QUEUE_ADD, null, "wa-${System.currentTimeMillis()}")
    }

    override fun onDestroy() {
        localTts?.stop()
        localTts?.shutdown()
        localTts = null
        ttsInitialized = false
        super.onDestroy()
    }

    companion object {
        private val WHATSAPP_PACKAGES = setOf("com.whatsapp", "com.whatsapp.w4b")
        private const val DEDUP_WINDOW_MS = 4_000L

        fun isNotificationAccessGranted(context: Context): Boolean {
            val enabledPackages = NotificationManagerCompat.getEnabledListenerPackages(context)
            return enabledPackages.contains(context.packageName)
        }

        fun serviceComponent(context: Context): ComponentName =
            ComponentName(context, WhatsAppNotificationListenerService::class.java)
    }
}
