package com.sanjay.jarvis.domain

import com.sanjay.jarvis.model.AiBrainPrefs
import com.sanjay.jarvis.model.JarvisMessage
import com.sanjay.jarvis.model.LanguageMode
import com.sanjay.jarvis.model.SmartMemoryItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

import com.sanjay.jarvis.model.ConversationTopic

data class AiBrainOutput(
    val usedExternalAi: Boolean,
    val intent: String,
    val detectedLanguage: String,
    val extractedCity: String? = null,
    val forecastDay: String = "today",
    val appTarget: String? = null,
    val replyEn: String,
    val replyTa: String
)

/**
 * Modular AI Brain adapter for native Android.
 * Calls the configured JARVIS backend (/api/jarvis/brain) when enabled, or falls back gracefully.
 */
class JarvisAiBrainService {

    suspend fun think(
        prompt: String,
        userName: String,
        languageMode: LanguageMode,
        aiPrefs: AiBrainPrefs,
        sessionContext: List<JarvisMessage>,
        savedMemories: List<SmartMemoryItem>
    ): AiBrainOutput = withContext(Dispatchers.IO) {
        val detectedLang = detectLanguage(prompt)
        if (!aiPrefs.enabled || aiPrefs.backendBaseUrl.isBlank()) {
            return@withContext localConversationalFallback(prompt, userName, detectedLang, aiPrefs.enabled)
        }

        runCatching {
            val endpoint = aiPrefs.backendBaseUrl.trimEnd('/') + "/api/jarvis/brain"
            val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                connectTimeout = 8000
                readTimeout = 12000
                setRequestProperty("Content-Type", "application/json")
            }

            val nowMs = System.currentTimeMillis()
            val freshWindow = sessionContext
                .filter { it.id != "init" && !it.id.startsWith("init-") && (nowMs - it.createdAtMillis) <= 30 * 60 * 1000L }
                .takeLast(8)

            val lastTopic = freshWindow.lastOrNull { it.contextTopic != null }?.contextTopic
            val lastCity = freshWindow.lastOrNull { !it.contextEntityCity.isNullOrBlank() }?.contextEntityCity

            val contextArray = JSONArray().apply {
                freshWindow.forEach { msg ->
                    put(JSONObject().apply {
                        put("sender", if (msg.isJarvis) "jarvis" else "user")
                        put("text", msg.text.take(300))
                    })
                }
            }

            val memoryArray = JSONArray().apply {
                if (aiPrefs.smartMemoryEnabled && aiPrefs.smartMemoryConsentAccepted) {
                    savedMemories.take(12).forEach { mem ->
                        put(JSONObject().apply {
                            put("label", mem.label)
                            put("value", mem.value)
                        })
                    }
                }
            }

            val payload = JSONObject().apply {
                put("prompt", prompt)
                put("languageMode", languageMode.name.lowercase(Locale.ROOT))
                put("userName", userName)
                put("sessionContext", contextArray)
                put("savedMemories", memoryArray)
                put("activeTopic", lastTopic?.name?.lowercase(Locale.ROOT) ?: JSONObject.NULL)
                put("activeCity", lastCity ?: JSONObject.NULL)
                put("preferredLanguage", detectedLang)
                put("allowMemorySuggestion", false)
            }

            conn.outputStream.use { os ->
                os.write(payload.toString().toByteArray(Charsets.UTF_8))
            }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299 || body.isBlank()) {
                return@withContext AiBrainOutput(
                    usedExternalAi = false,
                    intent = "conversation",
                    detectedLanguage = detectedLang,
                    replyEn = "External AI Brain is temporarily unavailable (HTTP $code). Local commands remain ready, $userName.",
                    replyTa = "வெளிப்புற AI சேவை தற்போது கிடைக்கவில்லை $userName. மற்ற JARVIS வசதிகள் தயாராக உள்ளன."
                )
            }

            val json = JSONObject(body)
            AiBrainOutput(
                usedExternalAi = json.optString("source") == "gemini",
                intent = json.optString("intent", "conversation"),
                detectedLanguage = json.optString("detectedLanguage", detectedLang),
                extractedCity = json.optString("extractedCity", "").ifBlank { null },
                forecastDay = json.optString("forecastDay", "today"),
                appTarget = json.optString("appTarget", "").ifBlank { null },
                replyEn = json.optString("replyEn", "I'm ready, $userName."),
                replyTa = json.optString("replyTa", "தயாராக உள்ளேன், $userName.")
            )
        }.getOrElse {
            localConversationalFallback(prompt, userName, detectedLang, aiPrefs.enabled)
        }
    }

    private fun detectLanguage(input: String): String {
        if (input.any { it in '\u0B80'..'\u0BFF' }) return "tamil"
        val tanglish = Regex("\\b(epdi|eppadi|iruku|irukku|enna|sollu|pannu|venum|naalaiku|innaiku|nandri|mazhai)\\b", RegexOption.IGNORE_CASE)
        return if (tanglish.containsMatchIn(input)) "tanglish" else "english"
    }

    private fun localConversationalFallback(
        prompt: String,
        userName: String,
        detectedLang: String,
        aiEnabled: Boolean
    ): AiBrainOutput {
        val en = if (aiEnabled) {
            "Command received, $userName. Local AI core online for \"$prompt\"."
        } else {
            "External AI Brain is paused, $userName. Weather, tasks, and voice controls work locally."
        }
        val ta = "கட்டளை பெறப்பட்டது $userName! Systems online buddy."
        return AiBrainOutput(
            usedExternalAi = false,
            intent = "conversation",
            detectedLanguage = detectedLang,
            replyEn = en,
            replyTa = ta
        )
    }
}
