package com.sanjay.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.sanjay.jarvis.data.PreferencesStore
import com.sanjay.jarvis.domain.JarvisCommandProcessor
import com.sanjay.jarvis.model.*
import com.sanjay.jarvis.service.WhatsAppNotificationListenerService
import com.sanjay.jarvis.ui.JarvisHudScreen
import com.sanjay.jarvis.ui.JarvisSettingsDialog
import com.sanjay.jarvis.voice.DeviceVoiceOption
import com.sanjay.jarvis.voice.JarvisVoiceEngine
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class MainActivity : ComponentActivity() {

    private lateinit var preferencesStore: PreferencesStore
    private lateinit var voiceEngine: JarvisVoiceEngine
    private lateinit var commandProcessor: JarvisCommandProcessor

    private var lastMicClickMillis = 0L
    private var lastExecutedCommand = ""
    private var lastExecutedCommandMillis = 0L

    private val micPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            onMicPermissionGrantedCallback?.invoke()
        } else {
            onMicErrorCallback?.invoke("Microphone permission denied. Please enable Microphone permission in Android Settings.")
        }
    }

    private val postNotificationLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {
        onRefreshPermissionsCallback?.invoke()
    }

    private val locationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    private var onMicPermissionGrantedCallback: (() -> Unit)? = null
    private var onMicErrorCallback: ((String) -> Unit)? = null
    private var onRefreshPermissionsCallback: (() -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        preferencesStore = PreferencesStore(this)
        voiceEngine = JarvisVoiceEngine(this)
        commandProcessor = JarvisCommandProcessor(this)

        setContent {
            var settings by remember { mutableStateOf(preferencesStore.loadSettings()) }
            var tasks by remember { mutableStateOf(preferencesStore.loadTasks()) }
            var savedMemories by remember { mutableStateOf(preferencesStore.loadMemories()) }
            var pendingDraft by remember { mutableStateOf<PendingTaskDraft?>(null) }
            var assistantState by remember { mutableStateOf(AssistantState.IDLE) }
            var interimTranscript by remember { mutableStateOf("") }
            var micError by remember { mutableStateOf<String?>(null) }
            var showSettings by remember { mutableStateOf(false) }

            var availableVoices by remember { mutableStateOf<List<DeviceVoiceOption>>(emptyList()) }
            var activeVoiceName by remember { mutableStateOf("System Default") }

            var notificationAccessGranted by remember {
                mutableStateOf(WhatsAppNotificationListenerService.isNotificationAccessGranted(this))
            }
            var postNotificationsGranted by remember {
                mutableStateOf(hasPostNotificationsPermission())
            }

            val messages = remember {
                mutableStateListOf<JarvisMessage>().apply {
                    val stored = preferencesStore.loadHistory()
                    if (stored.isNotEmpty()) {
                        addAll(stored)
                    } else {
                        add(
                            JarvisMessage(
                                id = "init",
                                isJarvis = true,
                                text = "Hello ${settings.userName}! JARVIS online and ready. Enna venum buddy?",
                                tamilText = "வணக்கம் ${settings.userName}! JARVIS தயார். என்ன வேணும் buddy?",
                                timestamp = currentTimeLabel()
                            )
                        )
                    }
                }
            }

            fun refreshPermissions() {
                notificationAccessGranted =
                    WhatsAppNotificationListenerService.isNotificationAccessGranted(this)
                postNotificationsGranted = hasPostNotificationsPermission()
            }

            onRefreshPermissionsCallback = { refreshPermissions() }

            LaunchedEffect(Unit) {
                voiceEngine.initializeTts { voices ->
                    availableVoices = voices
                    activeVoiceName = voiceEngine.resolvePreferredVoiceName(settings.selectedVoiceName)
                }
                if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_COARSE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED
                ) {
                    locationPermissionLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
                }
            }

            fun speakJarvis(english: String, tamil: String? = null) {
                if (settings.isMuted) {
                    assistantState = AssistantState.IDLE
                    return
                }
                assistantState = AssistantState.SPEAKING
                voiceEngine.speak(
                    englishText = english,
                    tamilText = tamil,
                    languageMode = settings.languageMode,
                    selectedVoiceName = settings.selectedVoiceName,
                    rate = settings.speechRate,
                    pitch = settings.speechPitch
                ) {
                    runOnUiThread {
                        if (assistantState == AssistantState.SPEAKING) {
                            assistantState = AssistantState.IDLE
                        }
                    }
                }
            }

            fun executeCommand(commandText: String) {
                val trimmed = commandText.trim()
                if (trimmed.isBlank()) return
                val now = System.currentTimeMillis()
                if (trimmed.equals(lastExecutedCommand, ignoreCase = true) && (now - lastExecutedCommandMillis) < 1500L) {
                    return
                }
                lastExecutedCommand = trimmed
                lastExecutedCommandMillis = now

                messages += JarvisMessage(
                    id = "user-${UUID.randomUUID()}",
                    isJarvis = false,
                    text = trimmed,
                    timestamp = currentTimeLabel(),
                    createdAtMillis = now
                )
                preferencesStore.saveHistory(messages.toList())
                interimTranscript = ""
                assistantState = AssistantState.PROCESSING

                lifecycleScope.launch {
                    val hasLoc = ContextCompat.checkSelfPermission(
                        this@MainActivity,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    ) == PackageManager.PERMISSION_GRANTED

                    val output = commandProcessor.process(
                        rawCommand = trimmed,
                        userName = settings.userName,
                        tasks = tasks,
                        pendingDraft = pendingDraft,
                        hasLocationPermission = hasLoc,
                        languageMode = settings.languageMode,
                        aiPrefs = settings.aiBrainPrefs,
                        sessionContext = messages.toList(),
                        savedMemories = savedMemories
                    )

                    output.addedTask?.let { newTask ->
                        tasks = listOf(newTask) + tasks
                        preferencesStore.saveTasks(tasks)
                    }
                    output.completedTaskId?.let { id ->
                        tasks = tasks.map {
                            if (it.id == id) it.copy(status = TaskStatus.COMPLETED) else it
                        }
                        preferencesStore.saveTasks(tasks)
                    }
                    output.deletedTaskId?.let { id ->
                        tasks = tasks.filterNot { it.id == id }
                        preferencesStore.saveTasks(tasks)
                    }
                    if (output.clearDraft) {
                        pendingDraft = null
                    } else if (output.updatedDraft != null) {
                        pendingDraft = output.updatedDraft
                    }
                    if (output.openSettingsSheet) {
                        refreshPermissions()
                        showSettings = true
                    }
                    output.launchPackageOrUrl?.let { target ->
                        runCatching {
                            val intent = if (target.startsWith("http")) {
                                Intent(Intent.ACTION_VIEW, Uri.parse(target))
                            } else {
                                packageManager.getLaunchIntentForPackage(target)
                                    ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://web.whatsapp.com"))
                            }
                            startActivity(intent)
                        }
                    }

                    messages += JarvisMessage(
                        id = "jarvis-${UUID.randomUUID()}",
                        isJarvis = true,
                        text = output.englishText,
                        tamilText = output.tamilText,
                        timestamp = currentTimeLabel(),
                        createdAtMillis = System.currentTimeMillis(),
                        weather = output.weather,
                        taskHighlights = output.taskHighlights,
                        usedExternalAi = output.usedExternalAi,
                        contextTopic = output.contextTopic,
                        contextEntityCity = output.contextEntityCity,
                        contextLanguage = output.contextLanguage
                    )
                    preferencesStore.saveHistory(messages.toList())
                    speakJarvis(output.englishText, output.tamilText)
                }
            }

            fun beginVoiceCapture() {
                micError = null
                assistantState = AssistantState.LISTENING
                voiceEngine.startListening(
                    languageMode = settings.languageMode,
                    onInterim = { interimTranscript = it },
                    onResult = { finalText ->
                        voiceEngine.stopListening()
                        interimTranscript = ""
                        executeCommand(finalText)
                    },
                    onError = { err ->
                        assistantState = AssistantState.IDLE
                        interimTranscript = ""
                        micError = err
                        // Never auto-restart on error
                    },
                    onEnd = {
                        if (assistantState == AssistantState.LISTENING) {
                            assistantState = AssistantState.IDLE
                        }
                        interimTranscript = ""
                    }
                )
            }

            fun handleMicPress() {
                val now = System.currentTimeMillis()
                // 500ms debounce
                if (now - lastMicClickMillis < 500L) return
                lastMicClickMillis = now

                if (assistantState == AssistantState.LISTENING) {
                    voiceEngine.stopListening()
                    assistantState = AssistantState.IDLE
                    return
                }
                if (assistantState == AssistantState.SPEAKING) {
                    voiceEngine.stopSpeaking()
                    assistantState = AssistantState.IDLE
                    return
                }

                val hasMic = ContextCompat.checkSelfPermission(
                    this@MainActivity,
                    Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED

                if (hasMic) {
                    beginVoiceCapture()
                } else {
                    onMicPermissionGrantedCallback = { beginVoiceCapture() }
                    onMicErrorCallback = { micError = it }
                    micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }
            }

            JarvisHudScreen(
                assistantState = assistantState,
                settings = settings,
                messages = messages,
                tasks = tasks,
                interimTranscript = interimTranscript,
                batteryPercent = commandProcessor.getBatteryPercent(),
                activeVoiceName = activeVoiceName,
                micError = micError,
                onMicPress = { handleMicPress() },
                onSubmitText = { executeCommand(it) },
                onSelectTheme = { themeId ->
                    settings = settings.copy(themeId = themeId)
                    preferencesStore.saveSettings(settings)
                },
                onCycleLanguage = {
                    val modes = LanguageMode.entries
                    val next = modes[(modes.indexOf(settings.languageMode) + 1) % modes.size]
                    settings = settings.copy(languageMode = next)
                    preferencesStore.saveSettings(settings)
                },
                onToggleMute = {
                    val nextMuted = !settings.isMuted
                    if (nextMuted) voiceEngine.stopSpeaking()
                    settings = settings.copy(isMuted = nextMuted)
                    preferencesStore.saveSettings(settings)
                },
                onToggleTaskStatus = { id ->
                    tasks = tasks.map {
                        if (it.id == id) {
                            it.copy(
                                status = if (it.status == TaskStatus.PENDING) TaskStatus.COMPLETED else TaskStatus.PENDING
                            )
                        } else it
                    }
                    preferencesStore.saveTasks(tasks)
                },
                onDeleteTask = { id ->
                    tasks = tasks.filterNot { it.id == id }
                    preferencesStore.saveTasks(tasks)
                },
                onAddManualTask = { title, priority ->
                    tasks = listOf(
                        JarvisTask(
                            id = "task-${UUID.randomUUID()}",
                            title = title,
                            priority = priority,
                            reminderEnabled = settings.taskRemindersEnabled
                        )
                    ) + tasks
                    preferencesStore.saveTasks(tasks)
                },
                onClearHistory = {
                    preferencesStore.clearHistory()
                    pendingDraft = null
                    messages.clear()
                    messages += JarvisMessage(
                        id = "init-${System.currentTimeMillis()}",
                        isJarvis = true,
                        text = "Conversation history cleared. Ready when you are, ${settings.userName}.",
                        tamilText = "உரையாடல் வரலாறு நீக்கப்பட்டது. புதிதாக பேச தயார், ${settings.userName}.",
                        timestamp = currentTimeLabel()
                    )
                },
                onOpenSettings = {
                    refreshPermissions()
                    showSettings = true
                },
                onDismissMicError = { micError = null }
            )

            if (showSettings) {
                JarvisSettingsDialog(
                    settings = settings,
                    palette = HologramThemes.get(settings.themeId),
                    availableVoices = availableVoices,
                    activeVoiceName = activeVoiceName,
                    notificationAccessGranted = notificationAccessGranted,
                    postNotificationsGranted = postNotificationsGranted,
                    savedMemories = savedMemories,
                    onUpdateMemories = { nextMemories ->
                        savedMemories = nextMemories
                        preferencesStore.saveMemories(nextMemories)
                    },
                    onClearSessionContext = {
                        messages.clear()
                        messages += JarvisMessage(
                            id = "init-${System.currentTimeMillis()}",
                            isJarvis = true,
                            text = "Temporary session context cleared. Ready for a fresh conversation, ${settings.userName}.",
                            tamilText = "தற்காலிக உரையாடல் நினைவு நீக்கப்பட்டது. புதிதாக பேச தயார், ${settings.userName}.",
                            timestamp = currentTimeLabel()
                        )
                    },
                    onRequestPostNotificationPermission = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            postNotificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    },
                    onRefreshPermissions = { refreshPermissions() },
                    onTestSelectedVoice = {
                        speakJarvis("Hello ${settings.userName}. This is JARVIS. Voice system online.")
                    },
                    onTestWhatsAppAnnouncement = { sample ->
                        speakJarvis(sample, sample)
                    },
                    onSave = { updated ->
                        settings = updated
                        preferencesStore.saveSettings(updated)
                        activeVoiceName = voiceEngine.resolvePreferredVoiceName(updated.selectedVoiceName)
                    },
                    onDismiss = { showSettings = false }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        onRefreshPermissionsCallback?.invoke()
    }

    override fun onStop() {
        super.onStop()
        voiceEngine.stopListening()
    }

    override fun onDestroy() {
        voiceEngine.shutdown()
        super.onDestroy()
    }

    private fun hasPostNotificationsPermission(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return true
        return ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun currentTimeLabel(): String =
        SimpleDateFormat("h:mm a", Locale.US).format(Date())
}
