# Keep JARVIS Android model classes and NotificationListenerService entry points
-keep class com.sanjay.jarvis.model.** { *; }
-keep class com.sanjay.jarvis.service.WhatsAppNotificationListenerService { *; }

# Keep AndroidX / Compose / Coroutines essentials
-keepattributes *Annotation*
-dontwarn kotlinx.coroutines.**
