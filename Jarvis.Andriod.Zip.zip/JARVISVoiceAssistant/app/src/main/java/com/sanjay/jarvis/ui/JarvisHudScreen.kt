package com.sanjay.jarvis.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sanjay.jarvis.model.*

enum class HudTab(val label: String) {
    CONSOLE("Console"),
    TASKS("Tasks"),
    HISTORY("History"),
    DIRECTIVES("Directives")
}

@Composable
fun JarvisHudScreen(
    assistantState: AssistantState,
    settings: JarvisSettings,
    messages: List<JarvisMessage>,
    tasks: List<JarvisTask>,
    interimTranscript: String,
    batteryPercent: Int,
    activeVoiceName: String,
    micError: String?,
    onMicPress: () -> Unit,
    onSubmitText: (String) -> Unit,
    onSelectTheme: (HologramThemeId) -> Unit,
    onCycleLanguage: () -> Unit,
    onToggleMute: () -> Unit,
    onToggleTaskStatus: (String) -> Unit,
    onDeleteTask: (String) -> Unit,
    onAddManualTask: (String, TaskPriority) -> Unit,
    onClearHistory: () -> Unit,
    onOpenSettings: () -> Unit,
    onDismissMicError: () -> Unit
) {
    val palette = HologramThemes.get(settings.themeId)
    val animatedPrimary by animateColorAsState(
        targetValue = palette.primary,
        animationSpec = tween(durationMillis = 500),
        label = "hudPrimary"
    )
    val animatedBright by animateColorAsState(
        targetValue = palette.bright,
        animationSpec = tween(durationMillis = 500),
        label = "hudBright"
    )

    var activeTab by remember { mutableStateOf(HudTab.CONSOLE) }
    var textInput by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF05080F))
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // Top HUD Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xCC020617))
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(
                    modifier = Modifier
                        .size(26.dp)
                        .background(palette.badgeBg, RoundedCornerShape(8.dp))
                        .border(1.dp, animatedBright, RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("J", color = animatedBright, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Text("J.A.R.V.I.S.", color = animatedBright, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    modifier = Modifier.clickable { onCycleLanguage() },
                    shape = RoundedCornerShape(50),
                    color = Color(0xFF0F172A),
                    border = BorderStroke(1.dp, palette.border)
                ) {
                    Text(
                        settings.languageMode.label,
                        color = animatedBright,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
                IconButton(onClick = onToggleMute, modifier = Modifier.size(34.dp)) {
                    Icon(
                        if (settings.isMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                        contentDescription = "Mute toggle",
                        tint = if (settings.isMuted) Color(0xFFF87171) else animatedBright,
                        modifier = Modifier.size(18.dp)
                    )
                }
                IconButton(onClick = onOpenSettings, modifier = Modifier.size(34.dp)) {
                    Icon(
                        Icons.Default.Settings,
                        contentDescription = "Settings",
                        tint = Color(0xFFCBD5E1),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        // Telemetry Ribbon
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xE6020617))
                .padding(horizontal = 14.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                "VOICE: $activeVoiceName",
                color = animatedBright,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            Text(
                "BAT $batteryPercent% · ${if (settings.whatsappPrefs.enabled) "WA ON" else "WA OFF"}",
                color = Color(0xFF94A3B8),
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        // Hologram Theme Switcher Strip
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            HologramThemeId.entries.forEach { id ->
                val theme = HologramThemes.get(id)
                val selected = settings.themeId == id
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onSelectTheme(id) },
                    shape = RoundedCornerShape(10.dp),
                    color = if (selected) theme.softSurface else Color(0xFF0F172A),
                    border = BorderStroke(1.dp, if (selected) theme.bright else Color(0xFF1E293B))
                ) {
                    Text(
                        id.shortName,
                        fontSize = 10.sp,
                        color = if (selected) theme.bright else Color(0xFF94A3B8),
                        maxLines = 1,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 6.dp)
                    )
                }
            }
        }

        if (micError != null) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 4.dp),
                shape = RoundedCornerShape(12.dp),
                color = Color(0xCC450A0A),
                border = BorderStroke(1.dp, Color(0xFFEF4444))
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(micError, color = Color(0xFFFECACA), fontSize = 11.sp, modifier = Modifier.weight(1f))
                    TextButton(onClick = onDismissMicError) {
                        Text("Dismiss", color = Color.White, fontSize = 11.sp)
                    }
                }
            }
        }

        // Arc Reactor Hero
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            ArcReactorOrb(
                state = assistantState,
                primary = animatedPrimary,
                bright = animatedBright,
                onClick = onMicPress
            )
        }

        // Tab Switcher: Console / Tasks / Directives
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xE6020617))
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            HudTab.entries.forEach { tab ->
                val active = activeTab == tab
                val label = if (tab == HudTab.TASKS) {
                    "Tasks (${tasks.count { it.status == TaskStatus.PENDING }})"
                } else {
                    tab.label
                }
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { activeTab = tab },
                    shape = RoundedCornerShape(10.dp),
                    color = if (active) palette.softSurface else Color.Transparent,
                    border = if (active) BorderStroke(1.dp, animatedPrimary) else null
                ) {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(vertical = 8.dp)) {
                        Text(
                            label,
                            fontSize = 12.sp,
                            fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (active) animatedBright else Color(0xFF94A3B8)
                        )
                    }
                }
            }
        }

        // Main Content Zone
        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            when (activeTab) {
                HudTab.CONSOLE -> ConsoleFeed(
                    messages = messages,
                    interimTranscript = interimTranscript,
                    palette = palette,
                    bright = animatedBright
                )
                HudTab.TASKS -> NativeTaskManagerView(
                    tasks = tasks,
                    palette = palette,
                    bright = animatedBright,
                    onToggleTask = onToggleTaskStatus,
                    onDeleteTask = onDeleteTask,
                    onAddTask = onAddManualTask
                )
                HudTab.HISTORY -> HistoryFeed(
                    messages = messages,
                    palette = palette,
                    bright = animatedBright,
                    onClearHistory = onClearHistory
                )
                HudTab.DIRECTIVES -> DirectivesFeed(
                    palette = palette,
                    bright = animatedBright,
                    onRunDirective = { cmd ->
                        onSubmitText(cmd)
                        activeTab = HudTab.CONSOLE
                    }
                )
            }
        }

        // Bottom Text Command Input
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xF0020617))
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = textInput,
                onValueChange = { textInput = it },
                placeholder = { Text("Say 'Hey Jarvis' or type command...", fontSize = 12.sp, color = Color(0xFF64748B)) },
                singleLine = true,
                modifier = Modifier.weight(1f),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = animatedBright,
                    unfocusedBorderColor = palette.border,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )
            IconButton(
                onClick = {
                    val trimmed = textInput.trim()
                    if (trimmed.isNotEmpty()) {
                        textInput = ""
                        onSubmitText(trimmed)
                    }
                },
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(animatedPrimary)
            ) {
                Icon(Icons.Default.Send, contentDescription = "Send", tint = palette.onAccentText)
            }
        }
    }
}

@Composable
private fun ArcReactorOrb(
    state: AssistantState,
    primary: Color,
    bright: Color,
    onClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "arcReactor")
    val spinAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(if (state == AssistantState.LISTENING) 5000 else 16000, easing = LinearEasing)),
        label = "spin"
    )
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.96f,
        targetValue = if (state == AssistantState.LISTENING || state == AssistantState.SPEAKING) 1.07f else 1.01f,
        animationSpec = infiniteRepeatable(tween(1200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(134.dp)
                .clickable { onClick() },
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val radius = size.minDimension / 2f
                rotate(spinAngle) {
                    drawArc(
                        color = bright.copy(alpha = 0.65f),
                        startAngle = 0f,
                        sweepAngle = 240f,
                        useCenter = false,
                        style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
                rotate(-spinAngle * 0.7f) {
                    drawCircle(
                        color = primary.copy(alpha = 0.35f),
                        radius = radius * 0.78f * pulseScale,
                        style = Stroke(width = 2.dp.toPx())
                    )
                }
                drawCircle(
                    color = primary.copy(alpha = 0.22f),
                    radius = radius * 0.62f * pulseScale
                )
            }

            Box(
                modifier = Modifier
                    .size(74.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF082F49))
                    .border(2.dp, bright, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (state == AssistantState.LISTENING) Icons.Default.GraphicEq else Icons.Default.Mic,
                    contentDescription = "Microphone",
                    tint = bright,
                    modifier = Modifier.size(32.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = when (state) {
                AssistantState.LISTENING -> "LISTENING..."
                AssistantState.PROCESSING -> "PROCESSING..."
                AssistantState.SPEAKING -> "SPEAKING..."
                AssistantState.WAKE_DETECTED -> "WAKE DETECTED"
                AssistantState.IDLE -> "TAP TO SPEAK"
            },
            color = bright,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.4.sp
        )
    }
}

@Composable
private fun ConsoleFeed(
    messages: List<JarvisMessage>,
    interimTranscript: String,
    palette: HologramThemePalette,
    bright: Color
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(messages, key = { it.id }) { msg ->
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = if (msg.isJarvis) Alignment.Start else Alignment.End
            ) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = if (msg.isJarvis) Color(0xFF0F172A) else Color(0xFF1E293B),
                    border = BorderStroke(1.dp, if (msg.isJarvis) palette.border else Color(0x55F59E0B))
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (msg.isJarvis && msg.usedExternalAi) {
                            Text(
                                text = "EXTERNAL AI BRAIN",
                                color = bright,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                letterSpacing = 1.sp
                            )
                        }
                        Text(msg.text, color = Color.White, fontSize = 13.sp)
                        if (!msg.tamilText.isNullOrBlank() && msg.tamilText != msg.text) {
                            Text(msg.tamilText, color = bright, fontSize = 12.sp)
                        }
                        msg.weather?.let { w ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color(0xFF020617),
                                border = BorderStroke(1.dp, palette.border)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("${w.city} (${w.forecastLabel})", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                        Text("${w.conditionEn} · Humidity ${w.humidity}% · Wind ${w.windSpeedKmh} km/h", color = Color(0xFF94A3B8), fontSize = 11.sp)
                                    }
                                    Text("${w.temperatureC}°C", color = bright, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
        if (interimTranscript.isNotBlank()) {
            item {
                Text("\"$interimTranscript\"", color = Color(0xFFFCA5A5), fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun NativeTaskManagerView(
    tasks: List<JarvisTask>,
    palette: HologramThemePalette,
    bright: Color,
    onToggleTask: (String) -> Unit,
    onDeleteTask: (String) -> Unit,
    onAddTask: (String, TaskPriority) -> Unit
) {
    var search by remember { mutableStateOf("") }
    var quickTitle by remember { mutableStateOf("") }
    val filtered = tasks.filter {
        search.isBlank() || it.title.contains(search, ignoreCase = true)
    }
    val pending = filtered.filter { it.status == TaskStatus.PENDING }
    val completed = filtered.filter { it.status == TaskStatus.COMPLETED }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = quickTitle,
                    onValueChange = { quickTitle = it },
                    placeholder = { Text("Quick add task...", fontSize = 12.sp) },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                Button(
                    onClick = {
                        if (quickTitle.isNotBlank()) {
                            onAddTask(quickTitle.trim(), TaskPriority.MEDIUM)
                            quickTitle = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = palette.primary, contentColor = palette.onAccentText)
                ) {
                    Text("Add", fontSize = 12.sp)
                }
            }
        }
        item {
            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                placeholder = { Text("Search tasks...", fontSize = 12.sp) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            Text("PENDING (${pending.size})", color = bright, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
        }
        items(pending, key = { it.id }) { task ->
            TaskRowCard(task, palette, bright, onToggleTask, onDeleteTask)
        }
        item {
            Text("COMPLETED (${completed.size})", color = Color(0xFF94A3B8), fontSize = 11.sp, fontFamily = FontFamily.Monospace)
        }
        items(completed, key = { it.id }) { task ->
            TaskRowCard(task, palette, bright, onToggleTask, onDeleteTask)
        }
    }
}

@Composable
private fun TaskRowCard(
    task: JarvisTask,
    palette: HologramThemePalette,
    bright: Color,
    onToggle: (String) -> Unit,
    onDelete: (String) -> Unit
) {
    val isDone = task.status == TaskStatus.COMPLETED
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = Color(0xFF0F172A),
        border = BorderStroke(1.dp, if (isDone) Color(0xFF1E293B) else palette.border)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Checkbox(checked = isDone, onCheckedChange = { onToggle(task.id) })
                Column {
                    Text(
                        task.title,
                        color = if (isDone) Color(0xFF64748B) else Color.White,
                        textDecoration = if (isDone) TextDecoration.LineThrough else TextDecoration.None,
                        fontSize = 13.sp
                    )
                    Text(
                        "${task.priority.label}${task.dueDate?.let { " · $it" } ?: ""}${task.dueTime?.let { " $it" } ?: ""}",
                        color = bright.copy(alpha = 0.8f),
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
            IconButton(onClick = { onDelete(task.id) }) {
                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFF87171), modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
private fun HistoryFeed(
    messages: List<JarvisMessage>,
    palette: HologramThemePalette,
    bright: Color,
    onClearHistory: () -> Unit
) {
    var showConfirmDialog by remember { mutableStateOf(false) }
    val historyItems = messages.filter { it.id != "init" && !it.id.startsWith("init-") }.reversed()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("CONVERSATION HISTORY (${historyItems.size})", color = bright, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    Text("Stored locally on device. Up to 8 recent turns guide follow-ups.", color = Color(0xFF94A3B8), fontSize = 10.sp)
                }
                OutlinedButton(
                    onClick = { showConfirmDialog = true },
                    enabled = historyItems.isNotEmpty()
                ) {
                    Text("Clear History", fontSize = 11.sp, color = Color(0xFFFCA5A5))
                }
            }
        }
        items(historyItems, key = { it.id }) { msg ->
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFF0F172A),
                border = BorderStroke(1.dp, palette.border)
            ) {
                Column(modifier = Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        "${if (msg.isJarvis) "J.A.R.V.I.S." else "YOU"} · ${msg.timestamp}${msg.contextTopic?.let { " · ${it.name}" } ?: ""}",
                        color = bright,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(msg.text, color = Color.White, fontSize = 12.sp)
                }
            }
        }
    }

    if (showConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showConfirmDialog = false },
            containerColor = Color(0xFF0F172A),
            titleContentColor = bright,
            textContentColor = Color(0xFFE2E8F0),
            title = { Text("Clear Conversation History?", fontSize = 16.sp, fontWeight = FontWeight.SemiBold) },
            text = { Text("This clears locally saved conversation history and resets active follow-up context.", fontSize = 12.sp) },
            confirmButton = {
                Button(
                    onClick = {
                        showConfirmDialog = false
                        onClearHistory()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626), contentColor = Color.White)
                ) {
                    Text("Clear History")
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmDialog = false }) {
                    Text("Cancel", color = Color(0xFF94A3B8))
                }
            }
        )
    }
}

@Composable
private fun DirectivesFeed(
    palette: HologramThemePalette,
    bright: Color,
    onRunDirective: (String) -> Unit
) {
    val presets = listOf(
        "Good morning, Jarvis",
        "Jarvis, give me my daily briefing",
        "What's the weather in Chennai?",
        "Innaiku enna tasks iruku?",
        "Jarvis, add a task to call Kumar tomorrow at 6 PM.",
        "Jarvis, naalaiku AC service pannanum nu task add pannu.",
        "Jarvis, system status"
    )
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(presets) { cmd ->
            Surface(
                modifier = Modifier.fillMaxWidth().clickable { onRunDirective(cmd) },
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFF0F172A),
                border = BorderStroke(1.dp, palette.border)
            ) {
                Text(cmd, color = bright, fontSize = 12.sp, modifier = Modifier.padding(12.dp))
            }
        }
    }
}
