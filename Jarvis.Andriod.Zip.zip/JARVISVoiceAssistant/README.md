# J.A.R.V.I.S. Voice Assistant — Native Android (Kotlin + Jetpack Compose)

Complete Android Studio project for the JARVIS Voice Assistant, built with **Kotlin**, **Jetpack Compose (Material 3)**, **Android SpeechRecognizer & TextToSpeech**, **Open-Meteo Weather**, **AI/NLP Task Manager**, and the optional privacy-first **WhatsApp NotificationListenerService**.

## Project Structure

- `settings.gradle.kts` / `build.gradle.kts` / `gradle.properties` / `gradle/wrapper/gradle-wrapper.properties` — Gradle 8.9 + AGP 8.7.2 + Kotlin 2.0.21 setup
- `app/build.gradle.kts` / `app/proguard-rules.pro` — Android SDK 35 (`minSdk 26`), Compose BOM, Material 3, Coroutines
- `app/src/main/AndroidManifest.xml` — Permissions (`RECORD_AUDIO`, `ACCESS_COARSE_LOCATION`, `ACCESS_FINE_LOCATION`, `POST_NOTIFICATIONS`, `INTERNET`), `<queries>`, and `WhatsAppNotificationListenerService`
- `app/src/main/java/com/sanjay/jarvis/`
  - `MainActivity.kt` — Runtime permission launchers, lifecycle cleanup, single-instance mic debounce
  - `model/JarvisModels.kt` — Hologram themes, tasks, weather, WhatsApp privacy modes & settings models
  - `data/PreferencesStore.kt` — Local `SharedPreferences` storage (zero cloud uploads)
  - `voice/JarvisVoiceEngine.kt` — Single-instance `SpeechRecognizer` (no auto-restart loops) + male-prioritized `TextToSpeech`
  - `domain/JarvisCommandProcessor.kt` — Bilingual English/Tamil/Tanglish commands, weather, tasks with Tamil dates, app launch intents
  - `service/WhatsAppNotificationListenerService.kt` — Consent-gated, lock-screen-protected on-device WhatsApp announcement service
  - `ui/JarvisHudScreen.kt` — Animated Arc Reactor HUD, Hologram Theme Switcher, Console, Task Manager, Directives
  - `ui/WhatsAppSettingsSheet.kt` — Settings & Privacy modal with explicit consent dialog and Notification Access shortcut
- `app/src/main/res/` — Strings, dark HUD theme, colors, and adaptive Arc Reactor launcher icons
- `app/src/main/assets/jarvis_directives.json` — Preset bilingual voice directives

## Opening in Android Studio

1. Extract the downloaded ZIP archive (`jarvis-android-kotlin-project.zip`).
2. Launch **Android Studio** (Ladybug 2024.2.1 or newer recommended, JDK 17).
3. Choose **File > Open** and select the extracted folder (containing `settings.gradle.kts`).
4. Android Studio will automatically read `gradle/wrapper/gradle-wrapper.properties` (Gradle 8.9), download dependencies, and sync the project.
5. Connect an Android device (Android 8.0+ / API 26+) with USB Debugging enabled, or start an Emulator, and click **Run ('app')**.

## Enabling the Optional WhatsApp Notification Assistant

1. Open **Settings** inside JARVIS on your phone.
2. Toggle **WhatsApp Announcements** ON and confirm the **Privacy Consent** dialog.
3. Tap **Open Notification Access** to jump to **Android Settings > Special app access > Notification access** and enable **JARVIS Voice Assistant**.
4. Choose **Privacy Mode** (`"You have a new WhatsApp message."`) or **Read Mode** (speaks sender & message locally), while keeping **Allow Content on Lock Screen** OFF unless you explicitly want lock-screen playback.
